# VDTuner-style baseline: multi-objective Bayesian optimization (GP surrogates over recall
# and latency, Monte-Carlo expected-hypervolume-improvement acquisition), the algorithmic
# core of VDTuner (ICDE 24) adapted to our plan space (the full system tunes Milvus index +
# system parameters and is not directly portable). One MOBO exploration serves all latency
# budgets (like KappaTune's one profile); we report frontier-regret as a function of the
# number of plan evaluations.
import numpy as np, json, sys, glob, os
from path_config import GRID_DIR
GD = str(GRID_DIR)  # point KAPPATUNE_GRID_DIR at ssd/ for SSD-repriced grids
corpus=sys.argv[1]
Dxl={"sift-128-euclidean":128,"dbpedia-openai-1536-angular":1536,"glove-100-angular":100,"gist-960-euclidean":960,"nytimes-256-angular":256,"deep-image-96-angular":96}[corpus]
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
allentries=[]
for f in sorted(glob.glob(GD + f"/ktmulti_{corpus}_*.json")):
    d=json.load(open(f)); g={(c["npr"],c["L"]):(c["rec"],c["lat"]) for c in d["cells"]}
    mb=d.get("m_bytes")
    if mb is None: mb={"PQ":Dxl//8,"OPQ":Dxl//8,"RaBitQ":Dxl//8,"ScaNN":Dxl//4,"HNSW":4*Dxl+256}[d["codec"]]
    allentries.append((d["codec"],int(mb),g))
CKPT=[6,12,24,48,96]; S=32
MB={"tight":int(0.19*Dxl),"mid":int(0.30*Dxl),"loose":10**9}
print(f"# {corpus} VDTuner-style MOBO (qEHVI, 5 seeds) frontier-regret(pp) vs evals, per memory tier",flush=True)
for mbname,Mb in MB.items():
    entries=[e for e in allentries if e[1]<=Mb]
    cells=[(i,n,L) for i in range(len(entries)) for (n,L) in entries[i][2].keys()]
    if not cells: continue
    recs=np.array([entries[i][2][(n,L)][0] for (i,n,L) in cells]); lts=np.array([entries[i][2][(n,L)][1] for (i,n,L) in cells])
    Xc=np.array([[1.0 if entries[i][0].startswith("HNSW") else 0.0, np.log2(entries[i][1]), np.log2(n), np.log(L)] for (i,n,L) in cells])
    Xs=(Xc-Xc.mean(0))/(Xc.std(0)+1e-9)
    Tg=np.geomspace(lts.min()*1.05,lts.max()*1.2,8)
    def fr(T): c=recs[lts<=T+1e-9]; return c.max() if len(c) else 0.0
    REF=(0.0,-float(lts.max())*1.05)
    def hv2(pts):
        s=sorted(pts,key=lambda p:-p[0]); h=0.0; yprev=REF[1]
        for (x,y) in s:
            if y>yprev: h+=(x-REF[0])*(y-yprev); yprev=y
        return h
    def mobo_traj(seed,E=96):
        rng=np.random.default_rng(seed); ev=list(rng.choice(len(cells),3,replace=False)); out={}
        while True:
            for ck in CKPT:
                if len(ev)==ck and ck not in out:
                    rs=[]
                    for T in Tg:
                        feas=[j for j in ev if lts[j]<=T]
                        if feas:
                            jb=max(feas,key=lambda j:recs[j]); rs.append(fr(lts[jb])-recs[jb])
                    out[ck]=100*float(np.mean(rs)) if rs else float("nan")
            if len(ev)>=E or len(ev)>=len(cells): break
            try:
                gr=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],recs[ev])
                gl=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],lts[ev])
                mur,sdr=gr.predict(Xs,return_std=True); mul,sdl=gl.predict(Xs,return_std=True)
                front=[(recs[j],-lts[j]) for j in ev]; h0=hv2(front)
                best=-1.0; nx=-1
                cand=[j for j in range(len(cells)) if j not in set(ev)]
                if len(cand)>400: cand=list(rng.choice(cand,400,replace=False))
                zr=rng.standard_normal((S,)); zl=rng.standard_normal((S,))
                for j in cand:
                    ys=mur[j]+sdr[j]*zr; yl=-(mul[j]+sdl[j]*zl); imp=0.0
                    for s in range(S):
                        imp+=max(0.0,hv2(front+[(ys[s],yl[s])])-h0)
                    imp/=S
                    if imp>best: best=imp; nx=j
                ev.append(nx if nx>=0 else int(rng.integers(len(cells))))
            except Exception:
                ev.append(int(rng.integers(len(cells))))
        return out
    acc={ck:[] for ck in CKPT}
    for seed in range(5):
        out=mobo_traj(seed)
        for ck in CKPT:
            if ck in out: acc[ck].append(out[ck])
    msg="  ".join(f"E={ck}:{float(np.mean(v)):.2f}" for ck,v in acc.items() if v)
    print(f"XL[{mbname:5s}] {len(cells)} cells: {msg}",flush=True)
print(f"# KappaTune profile ~= {3*len(allentries)} search-equivalents",flush=True)
print("VDDONE",flush=True)
