# ScaNN-AH kappa probe (estimator codec, vscann env). Same protocol as kcb_rab.py:
# SAMPLE-BUILT searcher (100K) vs full 300K searcher; no .reorder() so search distances
# are the raw AH estimates; true distances via numpy on the returned candidates; g from
# the dumped reference-profile GT. Cleans up the npy dumps at the end (disk is tight).
import numpy as np, scann, json, os
from path_config import OUTPUT_DIR, output_path
POOL = 200
out = {}
for name in ["sift-128-euclidean", "dbpedia-openai-1536-angular"]:
    b = np.load(output_path(f"kcb_base_{name}.npy"))
    q = np.load(output_path(f"kcb_q_{name}.npy"))
    g = float(np.load(output_path(f"kcb_g_{name}.npy"))[0])
    for tag, bb in [("sample", b[:100000]), ("full", b)]:
        searcher = (scann.scann_ops_pybind.builder(bb, 10, "squared_l2")
                    .tree(num_leaves=1024, num_leaves_to_search=64,
                          training_sample_size=min(100000, len(bb)))
                    .score_ah(2, anisotropic_quantization_threshold=0.2)
                    .build())
        ids, dists = searcher.search_batched(q, final_num_neighbors=POOL, leaves_to_search=64)
        errs = []
        for i in range(len(q)):
            cand = ids[i].astype(np.int64)
            ok = (cand >= 0) & (cand < len(bb))   # guard padding (-1 or large sentinel)
            cand = cand[ok]
            true = ((q[i] - bb[cand]) ** 2).sum(1)
            errs.append(dists[i][ok] - true)
        s = float(np.concatenate(errs).std()); kap = s / g
        out[f"{name}|ScaNN|{tag}"] = kap
        print(f"{name}\tScaNN\t{tag}\ts={s:.5f}\tg={g:.6f}\tkappa={kap:.2f}", flush=True)
        del searcher
json.dump(out, open(output_path("kcb_kappa_scann.json"), "w"))
for name in ["sift-128-euclidean", "dbpedia-openai-1536-angular"]:
    for f in [f"kcb_base_{name}.npy", f"kcb_q_{name}.npy", f"kcb_g_{name}.npy"]:
        p = OUTPUT_DIR / f
        if os.path.exists(p): os.remove(p)
print("SCANNDONE", flush=True)
