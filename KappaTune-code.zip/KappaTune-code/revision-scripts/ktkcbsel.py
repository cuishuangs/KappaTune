# End-to-end codec selection driven by Phi(kappa) PREDICTIONS instead of per-codec
# measured recall profiles (closes the loop on C2). Setup mirrors sec:eval-codec
# (ktmerge.py, default-m codecs):
#  - reference = the stage-1 PQ profile (measured Rceil(n) at PROF nprobes + rho(L));
#  - each quantized candidate's recall surface is PREDICTED:
#      R_C(n,L) = clip( Rceil_ref(n) - (1 - rho_ref(L)) * Phi(kappa_C), 0, 1 ),
#    kappa_C from the cheap probes: codebook probe for PQ/OPQ (rev_kcb.log), sample-built
#    estimator probe for RaBitQ/ScaNN (kcb_kappa_*.json, "sample" tag); Phi = published
#    fit 0.56(1-e^{-kappa/22});
#  - HNSW has no quantizer (lbd=0): keeps its measured 3-point profile, as in Alg. 1;
#  - latency per codec from the PROF timed cells (lstsq), as in ktmerge.
# Reports Phi-driven regret + picks vs the full-profile path (ktmerge logic, same run)
# and the oracle. CPU-only simulation over the measured jsons.
import numpy as np, json, glob
from collections import Counter
from path_config import GRID_DIR, OUTPUT_DIR
K = 10; NPR = [4, 8, 16, 32, 64, 128]; LS = [10, 20, 50, 100, 200]; PROF = [4, 16, 64]; REF = 16
PHI = lambda k: 0.56 * (1 - np.exp(-k / 22.0))
KAPPA = {  # codebook probes, source rev_kcb.log (2026-06-07)
    ("sift-128-euclidean", "PQ"): 21.67, ("sift-128-euclidean", "OPQ"): 19.42,
    ("dbpedia-openai-1536-angular", "PQ"): 12.99,
}
for f in glob.glob(str(OUTPUT_DIR / "kcb_kappa_*.json")):
    for k, v in json.load(open(f)).items():
        name, codec, tag = k.split("|")
        if tag == "sample":
            KAPPA[(name, codec)] = float(v)
for corpus in ["sift-128-euclidean", "dbpedia-openai-1536-angular"]:
    codecs = {}
    for f in sorted(glob.glob(str(GRID_DIR / f"ktmulti_{corpus}_*.json"))):
        d = json.load(open(f))
        stem = f.split(f"{corpus}_")[1][:-5]
        if stem != d["codec"]:
            continue  # default-m jsons only (no m-suffix), matching sec:eval-codec
        codecs[d["codec"]] = {(c["npr"], c["L"]): (c["rec"], c["lat"]) for c in d["cells"]}
    def fit(g):
        Rr = {n: g[(n, K)][0] for n in PROF}; Rc = {n: g[(n, 200)][0] for n in PROF}
        lbd = Rc[REF] - Rr[REF]
        rho = {L: ((g[(REF, L)][0] - Rr[REF]) / lbd if lbd > 1e-9 else 1.0) for L in LS}
        A = []; y = []
        for n in [PROF[0], PROF[-1]]:
            for L in [K, 200]: A.append([1, n, L]); y.append(g[(n, L)][1])
        c0, cp, cr = np.linalg.lstsq(np.array(A, float), np.array(y, float), rcond=None)[0]
        return dict(xs=np.log2(PROF), rrv=[Rr[n] for n in PROF], rcv=[Rc[n] for n in PROF],
                    rho=rho, c0=c0, cp=cp, cr=cr)
    M = {c: fit(g) for c, g in codecs.items()}
    ref = M["PQ"]
    def rceil_ref(n): return float(np.interp(np.log2(n), ref["xs"], ref["rcv"]))
    def rho_ref(L): return float(np.interp(L, LS, [ref["rho"][l] for l in LS]))
    def pr_full(c, n, L):
        m = M[c]; rr = np.interp(np.log2(n), m["xs"], m["rrv"]); rc = np.interp(np.log2(n), m["xs"], m["rcv"])
        return rr + np.interp(L, LS, [m["rho"][l] for l in LS]) * (rc - rr)
    def pr_phi(c, n, L):
        if c == "HNSW" or c == "PQ":
            return pr_full(c, n, L)        # reference itself / no quantizer: measured profile
        kap = KAPPA.get((corpus, c))
        if kap is None:
            return None
        return float(np.clip(rceil_ref(n) - (1 - rho_ref(L)) * PHI(kap), 0, 1))
    def pl(c, n, L):
        m = M[c]; return m["c0"] + m["cp"] * n + m["cr"] * L
    cells = [(c, n, L) for c in codecs for n in NPR for L in LS if pr_phi(c, n, L) is not None]
    lats = [codecs[c][(n, L)][1] for (c, n, L) in cells]
    Tg = np.geomspace(min(lats) * 1.05, max(lats) * 1.2, 8)
    def frontier(T):
        v = [codecs[c][(n, L)][0] for (c, n, L) in cells if codecs[c][(n, L)][1] <= T + 1e-9]
        return max(v) if v else 0.0
    print(f"# {corpus} codecs={sorted(codecs)} kappas="
          f"{ {c: round(KAPPA[(corpus, c)], 1) for c in codecs if (corpus, c) in KAPPA} }", flush=True)
    for label, prfun in [("Phi-driven", pr_phi), ("full-profile", pr_full)]:
        regs = []; picks = []; orc = []
        for T in Tg:
            feas = [(c, n, L) for (c, n, L) in cells if pl(c, n, L) <= T]
            if feas:
                c, n, L = max(feas, key=lambda x: prfun(*x))
                rec, lat = codecs[c][(n, L)]
                regs.append(frontier(lat) - rec); picks.append(c)
            of = [(c, n, L) for (c, n, L) in cells if codecs[c][(n, L)][1] <= T + 1e-9]
            if of and label == "Phi-driven":
                orc.append(max(of, key=lambda x: codecs[x[0]][(x[1], x[2])][0])[0])
        print(f"  {label:12s} regret={100*np.mean(regs):.2f}pp picks={dict(Counter(picks))}"
              + (f" oracle={dict(Counter(orc))}" if orc else ""), flush=True)
print("KCBSELDONE", flush=True)
