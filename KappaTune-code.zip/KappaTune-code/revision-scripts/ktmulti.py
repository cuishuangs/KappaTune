# Measure one codec's (nprobe,L) recall-latency grid (min-of-reps), dump json. Run per env.
import numpy as np, h5py, time, sys, json
from path_config import data_path, grid_path
K=10; NPR=[4,8,16,32,64,128]; LS=[10,20,50,100,200]; P=200; reps=2
def norm(x): return (x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-12)).astype(np.float32)
def bpqm(D,t):
    bb=1
    for mm in range(1,D+1):
        if D%mm==0 and abs(mm-t)<abs(bb-t): bb=mm
    return bb
corpus=sys.argv[1]; ang=bool(int(sys.argv[2])); codec=sys.argv[3]
MDIV=int(sys.argv[4]) if len(sys.argv)>4 else 8
def topk_prefix(I,ex,L):
    # prefix-only refinement (sec 2 / prop:topL-monotone): K smallest among the refined L
    if L<=K: return I[:,:K]
    ordr=np.argpartition(ex,K,axis=1)[:,:K]
    return np.take_along_axis(I[:,:L],ordr,axis=1)
with h5py.File(data_path(f"{corpus}.hdf5")) as h:
    b=np.ascontiguousarray(h["train"][:300000],dtype=np.float32); q=np.ascontiguousarray(h["test"][:500],dtype=np.float32)
if ang: b=norm(b); q=norm(q)
b=np.ascontiguousarray(b); q=np.ascontiguousarray(q); D=b.shape[1]; m=bpqm(D,max(4,D//MDIV)); nq=len(q); grid={}
MEM={"PQ":m,"OPQ":m,"RaBitQ":D//8,"ScaNN":D//4,"HNSW":4*D+256}[codec]
if codec=="ScaNN":
    import scann
    metric="dot_product" if ang else "squared_l2"
    if ang: GT=np.argpartition(-(q@b.T),K,axis=1)[:,:K]
    else:
        bn=(b*b).sum(1); GT=np.argpartition(bn[None,:]-2.0*(q@b.T),K,axis=1)[:,:K]
    gts=[set(GT[i].tolist()) for i in range(nq)]
    sr=scann.scann_ops_pybind.builder(b,K,metric).tree(num_leaves=1024,num_leaves_to_search=64,training_sample_size=100000).score_ah(2,anisotropic_quantization_threshold=0.2).reorder(P).build()
    for npr in NPR:
        for L in LS:
            ts=[]
            for _ in range(reps):
                t0=time.perf_counter(); nb,_=sr.search_batched(q,leaves_to_search=npr,pre_reorder_num_neighbors=max(L,K),final_num_neighbors=K); ts.append((time.perf_counter()-t0)/nq*1000)
            rec=float(np.mean([len(gts[i]&set(nb[i].tolist()))/K for i in range(nq)])); grid[(npr,L)]=(rec,min(ts))
elif codec=="HNSW":
    import faiss
    fl=faiss.IndexFlatL2(D); fl.add(b); _,GT=fl.search(q,K); gts=[set(GT[i].tolist()) for i in range(nq)]; del fl
    idx=faiss.index_factory(D,"HNSW32",faiss.METRIC_L2); idx.hnsw.efConstruction=200; idx.add(b)
    EFS=[16,32,64,128,256,512]
    for ef,slot in zip(EFS,NPR):
        idx.hnsw.efSearch=ef; ss=[]
        for _ in range(reps):
            t0=time.perf_counter(); Dq,I=idx.search(q,P); ss.append((time.perf_counter()-t0)/nq*1000)
        sm=min(ss)
        for L in LS:
            rr=[]
            for _ in range(reps):
                t0=time.perf_counter()
                cand=np.clip(I[:,:L],0,len(b)-1); vecs=b[cand.reshape(-1)].reshape(nq,L,-1); ex=((q[:,None,:]-vecs)**2).sum(-1)
                tk=topk_prefix(I,ex,L)
                rr.append((time.perf_counter()-t0)/nq*1000)
            rec=float(np.mean([len(gts[i]&set(tk[i].tolist()))/K for i in range(nq)])); grid[(slot,L)]=(rec,sm+min(rr))
else:
    import faiss
    fac={"PQ":f"IVF1024,PQ{m}","OPQ":f"OPQ{m},IVF1024,PQ{m}","RaBitQ":"IVF1024,RaBitQ"}[codec]
    fl=faiss.IndexFlatL2(D); fl.add(b); _,GT=fl.search(q,K); gts=[set(GT[i].tolist()) for i in range(nq)]; del fl
    idx=faiss.index_factory(D,fac,faiss.METRIC_L2); idx.train(b[:min(len(b),100000)]); idx.add(b); ivf=faiss.extract_index_ivf(idx)
    for npr in NPR:
        ivf.nprobe=npr; ss=[]
        for _ in range(reps):
            t0=time.perf_counter(); Dq,I=idx.search(q,P); ss.append((time.perf_counter()-t0)/nq*1000)
        sm=min(ss)
        for L in LS:
            rr=[]
            for _ in range(reps):
                t0=time.perf_counter()
                cand=np.clip(I[:,:L],0,len(b)-1); vecs=b[cand.reshape(-1)].reshape(nq,L,-1); ex=((q[:,None,:]-vecs)**2).sum(-1)
                tk=topk_prefix(I,ex,L)
                rr.append((time.perf_counter()-t0)/nq*1000)
            rec=float(np.mean([len(gts[i]&set(tk[i].tolist()))/K for i in range(nq)])); grid[(npr,L)]=(rec,sm+min(rr))
tag=codec if MDIV==8 else f"{codec}m{m}"
out={"codec":tag,"corpus":corpus,"m_bytes":int(MEM),"cells":[{"npr":n,"L":L,"rec":r,"lat":l} for (n,L),(r,l) in grid.items()]}
json.dump(out,open(grid_path(f"ktmulti_{corpus}_{tag}.json"),"w")); print(f"{corpus} {tag} m_bytes={MEM} {len(grid)} cells",flush=True)
