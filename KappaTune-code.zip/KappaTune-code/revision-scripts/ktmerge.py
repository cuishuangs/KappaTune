# Multi-codec online selection: KappaTune profiles each codec from a cheap 3-nprobe subset,
# predicts, and globally picks codec+plan under budget; vs multi-codec oracle and fixed-PQ.
import numpy as np, json, sys, glob
from collections import Counter
from path_config import GRID_DIR
K=10; NPR=[4,8,16,32,64,128]; LS=[10,20,50,100,200]; PROF=[4,16,64]; REF=16
corpus=sys.argv[1]; codecs={}
for f in sorted(glob.glob(str(GRID_DIR / f"ktmulti_{corpus}_*.json"))):
    d=json.load(open(f)); codecs[d["codec"]]={(c["npr"],c["L"]):(c["rec"],c["lat"]) for c in d["cells"]}
def fit(g):
    Rr={n:g[(n,K)][0] for n in PROF}; Rc={n:g[(n,200)][0] for n in PROF}; lbd=Rc[REF]-Rr[REF]
    rho={L:((g[(REF,L)][0]-Rr[REF])/lbd if lbd>1e-9 else 1.0) for L in LS}
    A=[];y=[]
    for n in [PROF[0],PROF[-1]]:
        for L in [K,200]: A.append([1,n,L]); y.append(g[(n,L)][1])
    c0,cp,cr=np.linalg.lstsq(np.array(A,float),np.array(y,float),rcond=None)[0]
    return dict(xs=np.log2(PROF),rrv=[Rr[n] for n in PROF],rcv=[Rc[n] for n in PROF],rho=rho,c0=c0,cp=cp,cr=cr)
M={c:fit(g) for c,g in codecs.items()}
def pr(m,n,L): rr=np.interp(np.log2(n),m["xs"],m["rrv"]); rc=np.interp(np.log2(n),m["xs"],m["rcv"]); return rr+np.interp(L,LS,[m["rho"][l] for l in LS])*(rc-rr)
def pl(m,n,L): return m["c0"]+m["cp"]*n+m["cr"]*L
cells=[(c,n,L) for c in codecs for n in NPR for L in LS]
def frontier(T): return max([codecs[c][(n,L)][0] for (c,n,L) in cells if codecs[c][(n,L)][1]<=T+1e-9] or [0.0])
lats=[codecs[c][(n,L)][1] for (c,n,L) in cells]; Tg=np.geomspace(min(lats)*1.05,max(lats)*1.2,8)
print(f"# {corpus} codecs={list(codecs)}",flush=True); ktr=[];pqr=[];picks=[];orc=[]
for T in Tg:
    feas=[(c,n,L) for (c,n,L) in cells if pl(M[c],n,L)<=T]
    if feas:
        c,n,L=max(feas,key=lambda x:pr(M[x[0]],x[1],x[2])); rec,lat=codecs[c][(n,L)]; ktr.append(frontier(lat)-rec); picks.append(c)
    fp=[("PQ",n,L) for n in NPR for L in LS if "PQ" in codecs and pl(M["PQ"],n,L)<=T]
    if fp:
        _,n,L=max(fp,key=lambda x:pr(M["PQ"],x[1],x[2])); rec,lat=codecs["PQ"][(n,L)]; pqr.append(frontier(lat)-rec)
    of=[(c,n,L) for (c,n,L) in cells if codecs[c][(n,L)][1]<=T+1e-9]
    if of: orc.append(max(of,key=lambda x:codecs[x[0]][(x[1],x[2])][0])[0])
print(f"E2-multi mean frontier-regret (pp): KappaTune-multi={100*np.mean(ktr):.2f}  KappaTune-fixedPQ-only={100*np.mean(pqr):.2f}",flush=True)
print(f"KappaTune-multi codec picks across budgets: {dict(Counter(picks))}; oracle-best codec: {dict(Counter(orc))}",flush=True)
print("MERGEDONE",flush=True)
