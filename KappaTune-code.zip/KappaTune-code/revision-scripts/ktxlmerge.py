# XL plan space: codec x m x nprobe x L at P=200 with EXPLICIT MEMORY BUDGETS.
# KappaTune profiles each (codec,m) from a cheap 3-nprobe subset; baselines (BO-6, random-6)
# search the same feasible space. Budgets: (latency T) x (memory M per vector).
import numpy as np, json, sys, glob
from collections import Counter
from scipy.stats import norm as snorm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
from path_config import GRID_DIR
K=10; NPR=[4,8,16,32,64,128]; LS=[10,20,50,100,200]; PROF=[4,16,64]; REF=16
corpus=sys.argv[1]; entries=[]; Dxl={"sift-128-euclidean":128,"dbpedia-openai-1536-angular":1536,"glove-100-angular":100,"gist-960-euclidean":960,"nytimes-256-angular":256,"deep-image-96-angular":96}[corpus]
for f in sorted(glob.glob(str(GRID_DIR / f"ktmulti_{corpus}_*.json"))):
    d=json.load(open(f)); g={(c["npr"],c["L"]):(c["rec"],c["lat"]) for c in d["cells"]}
    mb=d.get("m_bytes")
    if mb is None:
        mb={"PQ":Dxl//8,"OPQ":Dxl//8,"RaBitQ":Dxl//8,"ScaNN":Dxl//4,"HNSW":4*Dxl+256}[d["codec"]]
    entries.append((d["codec"],int(mb),g))
def fit(g):
    Rr={n:g[(n,K)][0] for n in PROF}; Rc={n:g[(n,200)][0] for n in PROF}; lbd=Rc[REF]-Rr[REF]
    rho={L:((g[(REF,L)][0]-Rr[REF])/lbd if lbd>1e-9 else 1.0) for L in LS}
    A=[];y=[]
    for n in [PROF[0],PROF[-1]]:
        for L in [K,200]: A.append([1,n,L]); y.append(g[(n,L)][1])
    c0,cp,cr=np.linalg.lstsq(np.array(A,float),np.array(y,float),rcond=None)[0]
    return dict(xs=np.log2(PROF),rrv=[Rr[n] for n in PROF],rcv=[Rc[n] for n in PROF],rho=rho,c0=c0,cp=cp,cr=cr)
M={i:fit(g) for i,(_,_,g) in enumerate(entries)}
def pr(i,n,L): m=M[i]; rr=np.interp(np.log2(n),m["xs"],m["rrv"]); rc=np.interp(np.log2(n),m["xs"],m["rcv"]); return rr+np.interp(L,LS,[m["rho"][l] for l in LS])*(rc-rr)
def pl(i,n,L): m=M[i]; return m["c0"]+m["cp"]*n+m["cr"]*L
cells=[(i,n,L) for i in range(len(entries)) for n in NPR for L in LS]
def feas_mem(i,Mb): return entries[i][1]<=Mb
lats=[entries[i][2][(n,L)][1] for (i,n,L) in cells]
Tg=np.geomspace(min(lats)*1.05,max(lats)*1.2,8)
MB={"tight":int(0.19*Dxl),"mid":int(0.30*Dxl),"loose":10**9}
print(f"# {corpus} XL space: {len(entries)} (codec,m) x {len(NPR)}x{len(LS)} = {len(cells)} plans; mem budgets/vec {MB}",flush=True)
Xc=np.array([[1.0 if entries[i][0].startswith('HNSW') else 0.0, np.log2(entries[i][1]), np.log2(n), np.log(L)] for (i,n,L) in cells])
Xs=(Xc-Xc.mean(0))/(Xc.std(0)+1e-9)
recs=np.array([entries[i][2][(n,L)][0] for (i,n,L) in cells]); lts=np.array(lats)
for mbname,Mb in MB.items():
    ok=[j for j,(i,n,L) in enumerate(cells) if feas_mem(i,Mb)]
    if not ok: continue
    def frontier(T): c=[recs[j] for j in ok if lts[j]<=T+1e-9]; return max(c) if c else 0.0
    def kt(T):
        best=None
        for j in ok:
            i,n,L=cells[j]
            if pl(i,n,L)<=T:
                r=pr(i,n,L)
                if best is None or r>best[0]: best=(r,j)
        return best[1] if best else None
    def rand6(T,seed):
        rng=np.random.default_rng(seed); samp=rng.choice(ok,min(6,len(ok)),replace=False)
        cs=[j for j in samp if lts[j]<=T]; return max(cs,key=lambda j:recs[j]) if cs else None
    def bo6(T,seed):
        rng=np.random.default_rng(seed); ev=list(rng.choice(ok,2,replace=False))
        while len(ev)<6:
            try:
                gr=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],recs[ev])
                gl=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],lts[ev])
                mu,sd=gr.predict(Xs[ok],return_std=True); bst=recs[ev].max(); z=(mu-bst)/(sd+1e-9)
                ei=(mu-bst)*snorm.cdf(z)+sd*snorm.pdf(z); lp=gl.predict(Xs[ok])
                for t,j in enumerate(ok):
                    if j in ev or lp[t]>T: ei[t]=-1e9
                tbest=int(np.argmax(ei))
                if ei[tbest]<=-1e8: break
                ev.append(ok[tbest])
            except Exception: break
        cs=[j for j in ev if lts[j]<=T]; return max(cs,key=lambda j:recs[j]) if cs else None
    def reg(fn,*a):
        rs=[]
        for T in Tg:
            j=fn(T,*a) if a else fn(T)
            if j is not None: rs.append(frontier(lts[j])-recs[j])
        return 100*float(np.mean(rs)) if rs else float("nan")
    ktr=reg(kt); rnd=float(np.mean([reg(rand6,s) for s in range(5)])); bor=float(np.mean([reg(bo6,s) for s in range(5)]))
    picks=Counter(entries[cells[kt(T)][0]][0] for T in Tg if kt(T) is not None)
    print(f"XL[{mbname:5s}] feasible_plans={len(ok)}  regret(pp): KappaTune={ktr:.2f}  BO6={bor:.2f}  random6={rnd:.2f}  picks={dict(picks)}",flush=True)
print("XLDONE",flush=True)
