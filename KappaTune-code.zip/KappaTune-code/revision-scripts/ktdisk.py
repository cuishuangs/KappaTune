# SSD-resident raw store: does KappaTune's measured-c_L cost model adapt when exact
# reranking pays a device read instead of a RAM gather?
#  1) O_DIRECT microbenchmark: per-fetch+distance cost, RAM vs SSD (c_L ratio).
#  2) Measured (nprobe,L) grid with DISK reranks -> the disk-resident Pareto frontier.
#  3) KappaTune profiles with disk rerank timings (same recall math, new c_L), optimizes,
#     and we report frontier-regret on the disk grid + the plan shift vs the RAM plans.
# Raw file is deleted at the end (box is near disk-full). Usage: ktdisk.py <name> <ang> <N>
import numpy as np, faiss, h5py, time, sys, os, mmap
from kappatune import build, bpqm, load, measure_grid, predict_latency, predict_recall, profile
from path_config import WORK_DIR, work_path
K = 10; BLK = 4096; NQ = 500
name = sys.argv[1]; ang = bool(int(sys.argv[2])); N = int(sys.argv[3])
RAW = work_path(f"rawstore_{name}.bin")

class DirectReader:
    def __init__(self, path, D):
        self.fd = os.open(path, os.O_RDONLY | os.O_DIRECT)
        self.row = 4 * D
        span = ((self.row // BLK) + 2) * BLK
        self.buf = mmap.mmap(-1, span)
        self.mv = memoryview(self.buf)
    def fetch_into(self, i, out):
        off = i * self.row
        a = (off // BLK) * BLK
        e = -(-(off + self.row) // BLK) * BLK
        os.preadv(self.fd, [self.mv[:e - a]], a)
        out[:] = np.frombuffer(self.mv[off - a:off - a + self.row], dtype=np.float32)
    def close(self):
        os.close(self.fd)

def rerank_disk_ms(reader, q, I, Dq, b, L, gts=None):
    nq = len(q); D = q.shape[1]
    V = np.empty((L, D), dtype=np.float32)
    t0 = time.perf_counter()
    tks = np.empty((nq, K), dtype=I.dtype)
    for i in range(nq):
        ids = I[i, :L]
        for j in range(L):
            reader.fetch_into(int(ids[j]) if ids[j] >= 0 else 0, V[j])
        ex = ((q[i] - V) ** 2).sum(1)
        # prefix-only refinement: K smallest among the refined L (sec 2 semantics)
        if L <= K:
            tks[i] = I[i, :K]
        else:
            ordr = np.argpartition(ex, K)[:K]
            tks[i] = I[i, :L][ordr]
    ms = (time.perf_counter() - t0) / nq * 1000
    rec = None
    if gts is not None:
        rec = float(np.mean([len(gts[i] & set(tks[i].tolist())) / K for i in range(nq)]))
    return ms, rec

def measure_grid_disk(b, q, GT, idx, reader, nprobes, Ls, P=200, reps=2):
    nq = len(q); gts = [set(GT[i, :K].tolist()) for i in range(nq)]
    ivf = faiss.extract_index_ivf(idx); cells = {}
    for npr in nprobes:
        ivf.nprobe = npr
        ts = []
        for r in range(3):
            t0 = time.perf_counter(); Dq, I = idx.search(q, P); ts.append((time.perf_counter() - t0) / nq * 1000)
        search_ms = min(ts)
        for L in Ls:
            if L > P: continue
            best = None; rec = None
            for r in range(reps):
                ms, rc = rerank_disk_ms(reader, q, I, Dq, b, L, gts if r == 0 else None)
                best = ms if best is None else min(best, ms)
                if rc is not None: rec = rc
            cells[(npr, L)] = (rec, search_ms + best)
    return cells

def profile_disk(b, q, GT, GTd, idx, reader, nprobes_prof, P=200, Ls=(10, 20, 50, 100, 200), reps=2):
    nq = len(q); gts = [set(GT[i, :K].tolist()) for i in range(nq)]
    ivf = faiss.extract_index_ivf(idx)
    Rraw = {}; Rceil = {}; cache = None; nsearch = 0; ref = nprobes_prof[len(nprobes_prof) // 2]
    for npr in nprobes_prof:
        ivf.nprobe = npr
        Dq, I = idx.search(q, P); nsearch += 1
        def rr(L): return float(np.mean([len(gts[i] & set(I[i, :L].tolist())) / K for i in range(nq)]))
        Rraw[npr] = rr(K); Rceil[npr] = rr(P)
        if npr == ref:
            cand = np.clip(I, 0, len(b) - 1); vecs = b[cand.reshape(-1)].reshape(nq, P, -1)
            dex = ((q[:, None, :] - vecs) ** 2).sum(-1); cache = (I.copy(), Dq.copy().astype(np.float32), dex)
    I0, Dq0, dex0 = cache; lbd0 = Rceil[ref] - Rraw[ref]; rho = {}
    for L in Ls:
        if L <= K:
            tk = I0[:, :K]
        else:
            ordr = np.argpartition(dex0[:, :L], K, axis=1)[:, :K]
            tk = np.take_along_axis(I0[:, :L], ordr, axis=1)
        recL = float(np.mean([len(gts[i] & set(tk[i].tolist())) / K for i in range(nq)]))
        rho[L] = (recL - Rraw[ref]) / lbd0 if lbd0 > 1e-9 else 1.0
    s = float((Dq0 - dex0).std()); g = float(np.median(GTd[:, K] - GTd[:, K - 1])); kappa = s / g if g > 0 else float("nan")
    def rt_disk(L):
        best = None
        for r in range(reps):
            ms, _ = rerank_disk_ms(reader, q, I0, Dq0, b, L)
            best = ms if best is None else min(best, ms)
        return best
    Llo, Lhi = Ls[0], Ls[-1]; rlo, rhi = rt_disk(Llo), rt_disk(Lhi); c_rerank = (rhi - rlo) / (Lhi - Llo)
    def stime(npr, r=3):
        ivf.nprobe = npr; ts = []
        for _ in range(r):
            t0 = time.perf_counter(); idx.search(q, P); ts.append((time.perf_counter() - t0) / len(q) * 1000)
        return min(ts)
    nlo, nhi = nprobes_prof[0], nprobes_prof[-1]; slo, shi = stime(nlo), stime(nhi)
    c_probe = (shi - slo) / (nhi - nlo)
    c0 = slo - c_probe * nlo + (rlo - c_rerank * Llo)
    sref = stime(ref)
    pa = [(sref + rt_disk(L)) / max(c0 + c_probe * ref + c_rerank * L, 1e-9) for L in (Llo, Lhi)]
    lat_scale = float(np.median(pa)) * 1.10
    xs = np.log2(np.array(nprobes_prof, dtype=float))
    rrv = np.array([Rraw[n] for n in nprobes_prof]); rcv = np.array([Rceil[n] for n in nprobes_prof])
    return dict(xs=xs, rrv=rrv, rcv=rcv, rho=rho, kappa=kappa, s=s, g=g, c0=c0, c_probe=c_probe,
                c_rerank=c_rerank, lat_scale=lat_scale, nsearch=nsearch, Ls=list(Ls))

# ---------- main ----------
b, q = load(name, ang, N=N, NQ=NQ)
D = b.shape[1]; m = bpqm(D, max(8, D // 8))
need = b.nbytes / 1e9
free = os.statvfs(WORK_DIR).f_bavail * os.statvfs(WORK_DIR).f_frsize / 1e9
print(f"# {name} N={len(b)} D={D} m={m} raw={need:.2f}GB free={free:.2f}GB", flush=True)
assert free > need + 1.0, "not enough disk space for raw store"
b.tofile(RAW)
fd = os.open(RAW, os.O_RDONLY); os.fsync(fd); os.close(fd)
try:
    reader = DirectReader(RAW, D)
    # self-test
    tmp = np.empty(D, dtype=np.float32); reader.fetch_into(12345 % len(b), tmp)
    assert np.allclose(tmp, b[12345 % len(b)]), "O_DIRECT reader mismatch"
    # 1) microbenchmark: RAM path vectorized (as the real rerank gathers), disk per-read
    rng = np.random.default_rng(0); ids = rng.integers(0, len(b), 2000)
    qv = q[0]
    t0 = time.perf_counter()
    for _ in range(50):
        vecs = b[ids]; _ = ((qv - vecs) ** 2).sum(1)
    us_ram = (time.perf_counter() - t0) / (50 * len(ids)) * 1e6
    t0 = time.perf_counter()
    for i in ids:
        reader.fetch_into(int(i), tmp); _ = ((qv - tmp) ** 2).sum()
    us_disk = (time.perf_counter() - t0) / len(ids) * 1e6
    print(f"MICRO c_L per exact distance: RAM={us_ram:.2f}us  SSD(O_DIRECT)={us_disk:.2f}us  ratio={us_disk/max(us_ram,1e-9):.1f}x", flush=True)
    # 2) GT + index
    f = faiss.IndexFlatL2(D); f.add(b); GTd, GT = f.search(q, 100); del f
    idx = build(b, D, "PQ", m)
    NPR = [4, 8, 16, 32, 64, 128]; LSL = [10, 20, 50, 100, 200]; P = 200
    # 3) RAM grid + RAM-profiled plans (the body's memory-resident protocol)
    grid_ram = measure_grid(b, q, GT, idx, NPR, LSL, P=P)
    model_ram = profile(b, q, GT, GTd, idx, [4, 16, 64], P=P, Ls=tuple(LSL))
    # 4) DISK grid + DISK-profiled plans
    grid_dsk = measure_grid_disk(b, q, GT, idx, reader, NPR, LSL, P=P)
    model_dsk = profile_disk(b, q, GT, GTd, idx, reader, [4, 16, 64], P=P, Ls=tuple(LSL))
    print(f"COEF ram: c0={model_ram['c0']:.4f} cp={model_ram['c_probe']:.5f} cr={model_ram['c_rerank']:.5f}", flush=True)
    print(f"COEF dsk: c0={model_dsk['c0']:.4f} cp={model_dsk['c_probe']:.5f} cr={model_dsk['c_rerank']:.5f} "
          f"cr_ratio={model_dsk['c_rerank']/max(model_ram['c_rerank'],1e-9):.1f}x", flush=True)
    def kt_plan(model, grid, T):
        best = None
        for npr in NPR:
            for L in LSL:
                if (npr, L) in grid and predict_latency(model, npr, L) <= T:
                    r = predict_recall(model, npr, L)
                    if best is None or r > best[0]: best = (r, (npr, L))
        return best[1] if best else None
    def frontier(grid, T):
        c = [v[0] for v in grid.values() if v[1] <= T + 1e-9]; return max(c) if c else 0.0
    def budgets(grid):
        lats = sorted(set(v[1] for v in grid.values())); return np.geomspace(min(lats) * 1.05, max(lats) * 1.2, 8)
    Tr, Td = budgets(grid_ram), budgets(grid_dsk)
    regs = []; adhs = []; shifts = []
    for t in range(8):
        pr_ = kt_plan(model_ram, grid_ram, Tr[t]); pd_ = kt_plan(model_dsk, grid_dsk, Td[t])
        if pd_:
            rec, lat = grid_dsk[pd_]; regs.append(frontier(grid_dsk, lat) - rec); adhs.append(lat / Td[t])
        shifts.append((t, pr_, pd_))
    print(f"DISK E2: kappatune regret={100*np.mean(regs):.2f}pp  adherence mean={np.mean(adhs):.2f} max={np.max(adhs):.2f}", flush=True)
    print("PLAN SHIFT (budget idx: RAM plan -> DISK plan, (nprobe,L)):", flush=True)
    for t, pr_, pd_ in shifts:
        print(f"  T{t}: {pr_} -> {pd_}", flush=True)
    Lr = [p[1] for _, p, _ in shifts if p]; Ld = [p[1] for _, _, p in shifts if p]
    nr = [p[0] for _, p, _ in shifts if p]; nd = [p[0] for _, _, p in shifts if p]
    print(f"SUMMARY mean L: RAM={np.mean(Lr):.0f} DISK={np.mean(Ld):.0f}; mean nprobe: RAM={np.mean(nr):.0f} DISK={np.mean(nd):.0f}", flush=True)
    reader.close()
finally:
    if os.path.exists(RAW):
        os.remove(RAW)
        print(f"# raw store {RAW} removed", flush=True)
print("DISKDONE", flush=True)
