"""Portable filesystem and service settings for the KappaTune experiments.

The scripts can run with their default self-contained layout, or callers can
override individual locations with environment variables.  Paths are resolved
once here so experiment code never needs machine-specific absolute paths.
"""

import os
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent


def _env_path(*names, default):
    for name in names:
        value = os.environ.get(name)
        if value:
            return Path(value).expanduser().resolve()
    return Path(default).expanduser().resolve()


EXPERIMENT_ROOT = _env_path("KAPPATUNE_ROOT", default=SCRIPT_DIR)
DATA_DIR = _env_path("KAPPATUNE_DATA_DIR", default=EXPERIMENT_ROOT / "data")
OUTPUT_DIR = _env_path("KAPPATUNE_OUTPUT_DIR", default=EXPERIMENT_ROOT / "outputs")
GRID_DIR = _env_path("KAPPATUNE_GRID_DIR", "GRIDDIR", default=OUTPUT_DIR)
WORK_DIR = _env_path("KAPPATUNE_WORK_DIR", default=OUTPUT_DIR / "work")
SSD_GRID_DIR = _env_path("KAPPATUNE_SSD_GRID_DIR", default=GRID_DIR / "ssd")
VDTUNER_DIR = _env_path(
    "KAPPATUNE_VDTUNER_DIR",
    default=EXPERIMENT_ROOT / "external" / "VDTuner" / "auto-configure",
)

MILVUS_HOST = os.environ.get("KAPPATUNE_MILVUS_HOST", "127.0.0.1")
MILVUS_PORT = os.environ.get("KAPPATUNE_MILVUS_PORT", "19530")


def _under(directory, name, create=False):
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory / name


def data_path(name):
    return _under(DATA_DIR, name)


def output_path(name):
    return _under(OUTPUT_DIR, name, create=True)


def grid_path(name):
    return _under(GRID_DIR, name, create=True)


def work_path(name):
    return _under(WORK_DIR, name, create=True)


def ssd_grid_path(name):
    return _under(SSD_GRID_DIR, name, create=True)
