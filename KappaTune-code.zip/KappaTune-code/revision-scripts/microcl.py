# O_DIRECT per-fetch microbenchmark for all six corpora at the XL-grid scale (300K).
# For each corpus: write the float32 raw store, verify an aligned read, measure the RAM
# gather+distance (vectorized, as the real rerank does) and the SSD O_DIRECT
# fetch+distance per vector, then delete the raw file (disk is tight). Coefficients are
# dumped to rev3_cl.json and feed the SSD repricing of the XL grids (xlreprice.py).
import numpy as np, h5py, time, os, mmap, json
from path_config import data_path, output_path, work_path
BLK = 4096
CORP = [("sift-128-euclidean", 0), ("dbpedia-openai-1536-angular", 1),
        ("gist-960-euclidean", 0), ("glove-100-angular", 1),
        ("nytimes-256-angular", 1), ("deep-image-96-angular", 1)]
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
out = {}
for name, ang in CORP:
    with h5py.File(data_path(f"{name}.hdf5")) as h:
        b = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
        q = np.ascontiguousarray(h["test"][:10], dtype=np.float32)
    if ang: b = norm(b); q = norm(q)
    b = np.ascontiguousarray(b); D = b.shape[1]
    path = work_path(f"rawstore_{name}.bin")
    b.tofile(path)
    fd = os.open(path, os.O_RDONLY); os.fsync(fd); os.close(fd)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECT); row = 4 * D
    span = ((row // BLK) + 2) * BLK; buf = mmap.mmap(-1, span); mv = memoryview(buf)
    def fetch(i, outv):
        off = i * row; a = (off // BLK) * BLK; e = -(-(off + row) // BLK) * BLK
        os.preadv(fd, [mv[:e - a]], a)
        outv[:] = np.frombuffer(mv[off - a:off - a + row], dtype=np.float32)
    tmp = np.empty(D, dtype=np.float32); fetch(12345, tmp)
    assert np.allclose(tmp, b[12345]), name
    rng = np.random.default_rng(0); ids = rng.integers(0, len(b), 2000); qv = q[0]
    t0 = time.perf_counter()
    for _ in range(50):
        vecs = b[ids]; _ = ((qv - vecs) ** 2).sum(1)
    us_ram = (time.perf_counter() - t0) / (50 * len(ids)) * 1e6
    t0 = time.perf_counter()
    for i in ids:
        fetch(int(i), tmp); _ = ((qv - tmp) ** 2).sum()
    us_disk = (time.perf_counter() - t0) / len(ids) * 1e6
    os.close(fd); os.remove(path)
    out[name] = {"us_ram": us_ram, "us_disk": us_disk}
    print(f"{name}: RAM={us_ram:.2f}us SSD={us_disk:.2f}us ratio={us_disk/max(us_ram,1e-9):.0f}x", flush=True)
json.dump(out, open(output_path("rev3_cl.json"), "w"))
print("MICRODONE", flush=True)
