# Explicit grid-search baseline (the "what practitioners do today" reference), computed on the
# SAME pre-measured rev3 SSD grid as every other baseline so the comparison isolates strategy.
# Two grids per (corpus, memory tier):
#   FULL   = exhaustive over all codec x m x nprobe x L cells -> by construction the oracle
#            (frontier-regret 0.0), at cost = total number of index builds it must measure.
#   COARSE = the folklore default-codec grid: sweep nprobe x L at fixed IVF-PQ (m=D/8) only.
#            Finds the best IVF-PQ plan but never tries other codecs, so it leaves real regret
#            in the heterogeneous space, at cost = #PQ cells (a practitioner's real grid).
# Reports frontier-regret(pp) at the latency the chosen plan actually uses + the build cost,
# so the table/figure can show KappaTune reaching the full-grid frontier at ~14x fewer builds.
import numpy as np, json, sys, glob, os
from path_config import GRID_DIR
GD = str(GRID_DIR)
corpus = sys.argv[1]
Dxl = {"sift-128-euclidean":128,"dbpedia-openai-1536-angular":1536,"glove-100-angular":100,
       "gist-960-euclidean":960,"nytimes-256-angular":256,"deep-image-96-angular":96}[corpus]
allentries = []        # (codec, m_bytes, {(npr,L):(rec,lat)}, is_default_pq)
for f in sorted(glob.glob(GD + f"/ktmulti_{corpus}_*.json")):
    d = json.load(open(f)); g = {(c["npr"], c["L"]): (c["rec"], c["lat"]) for c in d["cells"]}
    mb = d.get("m_bytes")
    if mb is None:
        mb = {"PQ":Dxl//8,"OPQ":Dxl//8,"RaBitQ":Dxl//8,"ScaNN":Dxl//4,"HNSW":4*Dxl+256}[d["codec"]]
    # the default-codec grid a practitioner sweeps = IVF-PQ at the default m=D/8, which is the
    # file ktmulti_<corpus>_PQ.json (m snaps to a divisor of D); the PQm96/PQm384 files are the
    # opened-up code-size variants and are NOT part of the folklore default grid.
    is_def = f.endswith(f"_PQ.json")
    allentries.append((d["codec"], int(mb), g, is_def))

MB = {"tight": int(0.19*Dxl), "mid": int(0.30*Dxl), "loose": 10**9}
print(f"# {corpus} grid-search baseline (full vs default-codec coarse) frontier-regret(pp) + build cost per tier", flush=True)
for mbname, Mb in MB.items():
    ents = [e for e in allentries if e[1] <= Mb]
    if not ents: continue
    cells = [(i, n, L) for i in range(len(ents)) for (n, L) in ents[i][2].keys()]
    recs = np.array([ents[i][2][(n,L)][0] for (i,n,L) in cells])
    lts  = np.array([ents[i][2][(n,L)][1] for (i,n,L) in cells])
    Tg = np.geomspace(lts.min()*1.05, lts.max()*1.2, 8)
    def fr(T):
        c = recs[lts <= T + 1e-9]; return float(c.max()) if len(c) else 0.0
    def grid_regret(mask):
        # mask: boolean over cells = which plans this grid measures. Pick best feasible at each T.
        idxs = np.where(mask)[0]
        rs = []
        for T in Tg:
            feas = [j for j in idxs if lts[j] <= T + 1e-9]
            if feas:
                jb = max(feas, key=lambda j: recs[j])
                rs.append(fr(lts[jb]) - recs[jb])
        return 100*float(np.mean(rs)) if rs else float("nan"), int(mask.sum())
    full_mask = np.ones(len(cells), dtype=bool)
    coarse_mask = np.array([ents[i][3] for (i,n,L) in cells], dtype=bool)  # default-PQ cells only
    fr_full, c_full = grid_regret(full_mask)
    fr_coarse, c_coarse = grid_regret(coarse_mask)
    kt_equiv = 3*len(ents)  # KappaTune profile cost = 3 searches per (codec,m) entry
    print(f"GRID[{mbname:5s}] {len(cells):3d} cells | FULL: regret={fr_full:.2f} builds={c_full:3d} | "
          f"COARSE-PQ: regret={fr_coarse:.2f} builds={c_coarse:2d} | KappaTune~{kt_equiv} search-equiv", flush=True)
print("GRIDDONE", flush=True)
