# KappaTune kappa=nan fallback on the XL space: when the frontier margin g is zero
# (tied true distances, kappa undefined; NYTimes), the interpolated profile is the case
# the diagnostic itself flags, so KappaTune escalates to a measured sweep of the
# memory-feasible plans and pays that cost explicitly. This script reruns the ktxlmerge
# protocol with the fallback wired in, recomputing g from the corpus (not hardcoded),
# and reports regret WITH and WITHOUT the fallback plus the measurement cost of each.
import numpy as np, json, sys, glob, h5py, faiss
from path_config import DATA_DIR, GRID_DIR

K = 10; NPR = [4, 8, 16, 32, 64, 128]; LS = [10, 20, 50, 100, 200]; PROF = [4, 16, 64]; REF = 16
corpus = sys.argv[1]
Dxl = {"sift-128-euclidean":128, "dbpedia-openai-1536-angular":1536, "glove-100-angular":100,
       "gist-960-euclidean":960, "nytimes-256-angular":256, "deep-image-96-angular":96}[corpus]
ANG = {"sift-128-euclidean":False, "gist-960-euclidean":False, "dbpedia-openai-1536-angular":True,
       "glove-100-angular":True, "nytimes-256-angular":True, "deep-image-96-angular":True}[corpus]

def norm(x): return (x/(np.linalg.norm(x, axis=1, keepdims=True)+1e-12)).astype(np.float32)
def margin_g():
    with h5py.File(DATA_DIR / f"{corpus}.hdf5") as h:
        b = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
        q = np.ascontiguousarray(h["test"][:1000], dtype=np.float32)
    if ANG: b = norm(b); q = norm(q)
    f = faiss.IndexFlatL2(b.shape[1]); f.add(b); GTd, _ = f.search(np.ascontiguousarray(q), K+1)
    return float(np.median(GTd[:, K] - GTd[:, K-1]))

g = margin_g()
FB = not (g > 1e-12)
print(f"# {corpus} frontier margin g={g:.6g} -> kappa {'UNDEFINED, fallback ON' if FB else 'defined, fallback off'}", flush=True)

entries = []
for f in sorted(glob.glob(str(GRID_DIR / f"ktmulti_{corpus}_*.json"))):
    d = json.load(open(f)); gg = {(c["npr"], c["L"]): (c["rec"], c["lat"]) for c in d["cells"]}
    mb = d.get("m_bytes")
    if mb is None:
        mb = {"PQ":Dxl//8, "OPQ":Dxl//8, "RaBitQ":Dxl//8, "ScaNN":Dxl//4, "HNSW":4*Dxl+256}[d["codec"]]
    entries.append((d["codec"], int(mb), gg))
def fit(gg):
    Rr = {n: gg[(n, K)][0] for n in PROF}; Rc = {n: gg[(n, 200)][0] for n in PROF}
    lbd = Rc[REF] - Rr[REF]
    rho = {L: ((gg[(REF, L)][0] - Rr[REF])/lbd if lbd > 1e-9 else 1.0) for L in LS}
    A = []; y = []
    for n in [PROF[0], PROF[-1]]:
        for L in [K, 200]: A.append([1, n, L]); y.append(gg[(n, L)][1])
    c0, cp, cr = np.linalg.lstsq(np.array(A, float), np.array(y, float), rcond=None)[0]
    return dict(xs=np.log2(PROF), rrv=[Rr[n] for n in PROF], rcv=[Rc[n] for n in PROF], rho=rho, c0=c0, cp=cp, cr=cr)
M = {i: fit(gg) for i, (_, _, gg) in enumerate(entries)}
def pr(i, n, L):
    m = M[i]; rr = np.interp(np.log2(n), m["xs"], m["rrv"]); rc = np.interp(np.log2(n), m["xs"], m["rcv"])
    return rr + np.interp(L, LS, [m["rho"][l] for l in LS])*(rc - rr)
def pl(i, n, L):
    m = M[i]; return m["c0"] + m["cp"]*n + m["cr"]*L
cells = [(i, n, L) for i in range(len(entries)) for n in NPR for L in LS]
recs = np.array([entries[i][2][(n, L)][0] for (i, n, L) in cells])
lts = np.array([entries[i][2][(n, L)][1] for (i, n, L) in cells])
Tg = np.geomspace(lts.min()*1.05, lts.max()*1.2, 8)
for mbname, Mb in {"tight": int(0.19*Dxl), "mid": int(0.30*Dxl), "loose": 10**9}.items():
    ok = [j for j, (i, n, L) in enumerate(cells) if entries[i][1] <= Mb]
    if not ok: continue
    def frontier(T):
        c = [recs[j] for j in ok if lts[j] <= T + 1e-9]; return max(c) if c else 0.0
    def kt_profile(T):
        best = None
        for j in ok:
            i, n, L = cells[j]
            if pl(i, n, L) <= T:
                r = pr(i, n, L)
                if best is None or r > best[0]: best = (r, j)
        return best[1] if best else None
    def kt_sweep(T):
        feas = [j for j in ok if lts[j] <= T]
        return max(feas, key=lambda j: recs[j]) if feas else None
    def reg(fn):
        rs = [frontier(lts[j]) - recs[j] for j in (fn(T) for T in Tg) if j is not None]
        return 100*float(np.mean(rs)) if rs else float("nan")
    prof_cost = 3*len(entries)          # 3-nprobe profile per (codec,m), search-equivalents
    sweep_cost = len(ok)                # measured sweep of feasible plans
    if FB:
        print(f"XL[{mbname:5s}] KT-profile={reg(kt_profile):.2f}pp (cost {prof_cost})  "
              f"KT-fallback(sweep)={reg(kt_sweep):.2f}pp (cost {sweep_cost})  -> fallback selected", flush=True)
    else:
        print(f"XL[{mbname:5s}] KT-profile={reg(kt_profile):.2f}pp (cost {prof_cost})  "
              f"[fallback not triggered; sweep would be {reg(kt_sweep):.2f}pp at cost {sweep_cost}]", flush=True)
print("FBDONE", flush=True)
