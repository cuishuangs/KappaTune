import numpy as np, faiss, h5py
from path_config import data_path
K=10; POOL=200; NQ=1000
def norm(x): return (x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-12)).astype(np.float32)
def run(b,q,D,m,quant,name):
    b=np.ascontiguousarray(b,dtype=np.float32); q=np.ascontiguousarray(q,dtype=np.float32)
    flat=faiss.IndexFlatL2(D); flat.add(b); GTd,GT=flat.search(q,100)
    fac=(f"OPQ{m},IVF1024,PQ{m}" if quant=="OPQ" else f"IVF1024,PQ{m}")
    idx=faiss.index_factory(D,fac,faiss.METRIC_L2); idx.train(b[:min(len(b),50000)]); idx.add(b); faiss.extract_index_ivf(idx).nprobe=64
    Dq,I=idx.search(q,POOL)
    gts=[set(GT[i,:K].tolist()) for i in range(len(q))]
    def rr(L): return float(np.mean([len(gts[i]&set(I[i,:L].tolist()))/K for i in range(len(q))]))
    Rraw=rr(K); Rceil=rr(POOL); lbd=Rceil-Rraw
    errs=[]
    for i in range(len(q)):
        cand=I[i]; cand=cand[cand>=0]; true=((q[i]-b[cand])**2).sum(1); est=Dq[i,:len(cand)]; errs.append(est-true)
    s=float(np.concatenate(errs).std())
    gap=float(np.median(GTd[:,K]-GTd[:,K-1]))
    kap=s/gap if gap>0 else float("nan")
    print(f"{name}\t{quant}\t{D}\t{lbd:.4f}\t{s:.5f}\t{gap:.6f}\t{kap:.3f}",flush=True); del idx,flat
print("name\tquant\tD\tlbd\ts_err\tmargin\tkappa",flush=True)
B=np.load(data_path("mxbai_base.npy")); Q=np.load(data_path("mxbai_q.npy"))
for D in [64,128,256,512,768,1024]:
    run(norm(B[:,:D]), norm(Q[:NQ,:D]), D, D//8, "OPQ", "mxbai")
run(norm(B[:,:512]), norm(Q[:NQ,:512]), 512, 64, "PQ", "mxbai")
for nm,ang,m,qs in [("sift-128-euclidean",False,16,["PQ","OPQ"]),("dbpedia-openai-1536-angular",True,192,["PQ"])]:
    with h5py.File(data_path(f"{nm}.hdf5")) as h:
        bb=np.ascontiguousarray(h["train"][:300000],dtype=np.float32); qq=np.ascontiguousarray(h["test"][:NQ],dtype=np.float32)
    if ang: bb=norm(bb); qq=norm(qq)
    D=bb.shape[1]
    for qn in qs: run(bb,qq,D,m,qn,nm)
print("KAPPADONE",flush=True)
