# F7: live-rows-only statistics for the cheap-kappa probes, for provenance.
# Same-family rows (PQ candidate vs PQ reference) coincide by construction and are
# EXCLUDED here. Live tests: (a) 10 codebook-probe rows where the candidate family
# differs from the reference (OPQ vs PQ ref), read from rev_kcb.log; (b) 4 sample-built
# estimator probes (RaBitQ/ScaNN x sift/dbpedia), sample-vs-full, from kcb_kappa_*.json.
# Reports live-only Spearman, rel-err quantiles, and Phi-prediction RMSE on live rows.
import json, numpy as np
from path_config import OUTPUT_DIR, output_path
rows = []   # (tag, lbd, kappa_full, kappa_cb)
for line in open(output_path("rev_kcb.log")):
    f = line.split("\t")
    if len(f) < 8 or not f[0].strip() or f[0].startswith("SUMMARY"):
        continue
    tag, quant = f[0], f[1]
    if quant != "OPQ":
        continue                       # OPQ candidates against the PQ reference = live
    lbd = float(f[4].split("=")[1]); kf = float(f[5].split("=")[1]); kc = float(f[6].split("=")[1])
    rows.append((f"{tag}-{f[2]}", lbd, kf, kc))
kf = np.array([r[2] for r in rows]); kc = np.array([r[3] for r in rows])
lbd = np.array([r[1] for r in rows])
def spearman(a, b):
    ra = np.argsort(np.argsort(a)); rb = np.argsort(np.argsort(b)); n = len(a)
    return 1 - 6 * np.sum((ra - rb) ** 2) / (n * (n * n - 1))
rel = np.abs(kc - kf) / kf
PHI = lambda k: 0.56 * (1 - np.exp(-k / 22.0))
rmse_cb = float(np.sqrt(np.mean((PHI(kc) - lbd) ** 2)))
rmse_full = float(np.sqrt(np.mean((PHI(kf) - lbd) ** 2)))
print(f"LIVE codebook rows n={len(rows)}: Spearman={spearman(kc, kf):.3f} "
      f"median_rel={np.median(rel):.3f} max_rel={rel.max():.3f} "
      f"Phi-RMSE cb={rmse_cb:.3f} full={rmse_full:.3f}", flush=True)
for t, l, a, b in rows:
    print(f"  {t}: lbd={l:.3f} kf={a:.2f} kc={b:.2f} rel={abs(b-a)/a:.3f}", flush=True)
est = {}
import glob
for f in glob.glob(str(OUTPUT_DIR / "kcb_kappa_*.json")):
    est.update(json.load(open(f)))
print("LIVE estimator probes (sample-built vs full):", flush=True)
for corpus in ["sift-128-euclidean", "dbpedia-openai-1536-angular"]:
    for codec in ["RaBitQ", "ScaNN"]:
        s = est.get(f"{corpus}|{codec}|sample"); fu = est.get(f"{corpus}|{codec}|full")
        if s and fu:
            print(f"  {corpus} {codec}: sample={s:.2f} full={fu:.2f} rel={abs(s-fu)/fu:.3f}", flush=True)
print("LIVEDONE", flush=True)
