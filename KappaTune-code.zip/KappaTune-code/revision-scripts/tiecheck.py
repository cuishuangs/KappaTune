# F1 verification: on NYTimes the full-rerank recall sits below the pool ceiling
# (e5 Rfull=0.768 vs e4 Rceil=0.795, same config/queries). Hypothesis: this is exactly
# the rank-k boundary TIE mass (the kappa=nan pathology), outside the paper's
# distinct-scores assumption: exact reranking picks arbitrarily among candidates tied
# with the k-th true distance, displacing "official" GT members that the
# presence-counting Rceil still credits. Verify: (a) reproduce the gap; (b) show the
# tie-free query subset satisfies Rfull == Rceil exactly; (c) DBpedia control (distinct
# distances, identity holds). Recall-only.
import numpy as np, faiss, h5py
from path_config import data_path
K = 10; POOL = 200; NQ = 2000
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
for name, ang, m in [("nytimes-256-angular", True, 32), ("dbpedia-openai-1536-angular", True, 192)]:
    with h5py.File(data_path(f"{name}.hdf5")) as h:
        b = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
        q = np.ascontiguousarray(h["test"][:NQ], dtype=np.float32)
    if ang: b = norm(b); q = norm(q)
    b = np.ascontiguousarray(b); q = np.ascontiguousarray(q); D = b.shape[1]
    fl = faiss.IndexFlatL2(D); fl.add(b); GTd, GT = fl.search(q, K + 1); del fl
    idx = faiss.index_factory(D, f"IVF1024,PQ{m}", faiss.METRIC_L2)
    idx.train(b[:100000]); idx.add(b)
    faiss.extract_index_ivf(idx).nprobe = 64
    dq, I = idx.search(q, POOL)
    nq = len(q); rce = np.zeros(nq); rfu = np.zeros(nq); tied = np.zeros(nq, bool)
    for i in range(nq):
        cand = I[i][I[i] >= 0]
        dex = ((q[i] - b[cand]) ** 2).sum(1)
        G = set(GT[i, :K].tolist())
        rce[i] = len(G & set(cand.tolist())) / K
        topk = cand[np.argsort(dex)[:K]]
        rfu[i] = len(G & set(topk.tolist())) / K
        dK = GTd[i, K - 1]; eps = 1e-6 * max(dK, 1e-9)
        # a boundary tie: some pool member OUTSIDE G sits at (or below) the k-th true distance
        out = [1 for c, d in zip(cand.tolist(), dex) if c not in G and d <= dK + eps]
        tied[i] = len(out) > 0
    gap = rce - rfu; nf = ~tied
    print(f"{name}: Rceil={rce.mean():.4f} Rfull={rfu.mean():.4f} gap={gap.mean():.4f} "
          f"tied_q={tied.mean():.3f}", flush=True)
    print(f"  tie-free subset ({nf.mean():.3f}): Rceil={rce[nf].mean():.4f} Rfull={rfu[nf].mean():.4f} "
          f"identity_exact={bool(np.all(np.abs(gap[nf]) < 1e-12))}", flush=True)
    if tied.any():
        print(f"  gap on tied queries: {gap[tied].mean():.4f} (x {tied.mean():.3f} mass = "
              f"{gap[tied].mean() * tied.mean():.4f} of the total {gap.mean():.4f})", flush=True)
print("TIEDONE", flush=True)
