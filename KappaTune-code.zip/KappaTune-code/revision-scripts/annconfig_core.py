# ann-config-core: the constrained-optimization core of Sun et al. (ICLR'23,
# "Automating Nearest Neighbor Search Configuration with Constrained Optimization"),
# adapted to our plan space the same way vdtune.py adapts VDTuner: the full method's
# analytic recall model is specific to partitioning-tree + AH geometry, so we keep its
# defining mechanism (fit smooth parametric recall/latency surrogates ONCE from E
# measured plans, then solve max recall s.t. latency<=T on the surrogate for every
# budget; one-shot model-based, no sequential acquisition) and swap in generic
# parametric forms: logit-linear recall and log-linear latency in
# [is_hnsw, log2 m_bytes, log2 nprobe, log L]. Ridge-regularized least squares.
# Reported at E in {6,12,24,48,96} measured plans, 5 seeds. CPU-only simulation.
import numpy as np, json, sys, glob
from path_config import GRID_DIR

corpus = sys.argv[1]
Dxl = {"sift-128-euclidean":128, "dbpedia-openai-1536-angular":1536, "glove-100-angular":100,
       "gist-960-euclidean":960, "nytimes-256-angular":256, "deep-image-96-angular":96}[corpus]
CKPT = [6, 12, 24, 48, 96]
SEEDS = 5
RIDGE = 1e-2

def load_entries(pq_only=False):
    # SMALL space = the default-m PQ grid, which lives in ktmulti_<corpus>_PQ.json
    # (match by filename, not by m_bytes: m snaps to a divisor of D, e.g. 10 for D=100).
    pat = (str(GRID_DIR / f"ktmulti_{corpus}_PQ.json") if pq_only
           else str(GRID_DIR / f"ktmulti_{corpus}_*.json"))
    entries = []
    for f in sorted(glob.glob(pat)):
        d = json.load(open(f))
        g = {(c["npr"], c["L"]): (c["rec"], c["lat"]) for c in d["cells"]}
        mb = d.get("m_bytes")
        if mb is None:
            mb = {"PQ":Dxl//8, "OPQ":Dxl//8, "RaBitQ":Dxl//8, "ScaNN":Dxl//4, "HNSW":4*Dxl+256}[d["codec"]]
        entries.append((d["codec"], int(mb), g))
    return entries

def logit(p): return np.log(np.clip(p, 1e-3, 1-1e-3) / (1 - np.clip(p, 1e-3, 1-1e-3)))
def ridge_fit(Phi, y):
    A = Phi.T @ Phi + RIDGE*np.eye(Phi.shape[1])
    return np.linalg.solve(A, Phi.T @ y)

def run(entries, Mb, tag):
    cells = [(i, n, L) for i in range(len(entries)) for (n, L) in entries[i][2].keys()
             if entries[i][1] <= Mb]
    if not cells:
        return
    recs = np.array([entries[i][2][(n, L)][0] for (i, n, L) in cells])
    lts  = np.array([entries[i][2][(n, L)][1] for (i, n, L) in cells])
    Phi = np.array([[1.0,
                     1.0 if entries[i][0].startswith("HNSW") else 0.0,
                     np.log2(entries[i][1]), np.log2(n), np.log(L)] for (i, n, L) in cells])
    mu, sd = Phi[:, 1:].mean(0), Phi[:, 1:].std(0) + 1e-9
    Phi[:, 1:] = (Phi[:, 1:] - mu) / sd
    Tg = np.geomspace(lts.min()*1.05, lts.max()*1.2, 8)
    def fr(T):
        c = recs[lts <= T + 1e-9]
        return c.max() if len(c) else 0.0
    acc = {ck: [] for ck in CKPT}; viol = {ck: 0 for ck in CKPT}; tot = {ck: 0 for ck in CKPT}
    for seed in range(SEEDS):
        rng = np.random.default_rng(seed)
        order = rng.permutation(len(cells))
        for ck in CKPT:
            tr = order[:min(ck, len(cells))]
            wr = ridge_fit(Phi[tr], logit(recs[tr]))
            wl = ridge_fit(Phi[tr], np.log(np.maximum(lts[tr], 1e-6)))
            pred_r = 1/(1 + np.exp(-(Phi @ wr)))
            pred_l = np.exp(Phi @ wl)
            for T in Tg:
                feas = np.where(pred_l <= T)[0]
                if len(feas) == 0:
                    continue
                j = int(feas[np.argmax(pred_r[feas])])
                acc[ck].append(fr(lts[j]) - recs[j])
                tot[ck] += 1
                if lts[j] > T:
                    viol[ck] += 1
    msg = "  ".join(f"E={ck}:{100*float(np.mean(v)):.2f}" for ck, v in acc.items() if v)
    vmsg = "  ".join(f"E={ck}:{viol[ck]}/{tot[ck]}" for ck in CKPT if tot[ck])
    print(f"{tag} plans={len(cells)} ann-config-core regret(pp): {msg}", flush=True)
    print(f"{tag} budget violations (deployed lat > T): {vmsg}", flush=True)

small = load_entries(pq_only=True)
print(f"# {corpus} ann-config-core (one-shot parametric surrogate + constrained argmax, {SEEDS} seeds)", flush=True)
run(small, 10**9, "SMALL")
xl = load_entries(pq_only=False)
for name, Mb in {"tight": int(0.19*Dxl), "mid": int(0.30*Dxl), "loose": 10**9}.items():
    run(xl, Mb, f"XL[{name}]")
print("ANNCFGDONE", flush=True)
