# RaBitQ kappa probe (estimator codec, vrab env / faiss 1.11). RaBitQ's score is an
# unbiased estimator, not a reconstruction distance, so the codebook re-encode probe does
# not apply; the cheap N-independent variant is the SAMPLE-BUILT probe: build the
# estimator on the 100K profile sample only (train+add sample), one search pass, s from
# (Dq - true) over its own pools; g reused from the reference profile's GT (a stage-1
# sunk cost). We report sample-built vs full-300K-built kappa. Also dumps base/q/g npys
# for the ScaNN probe (vscann env has no faiss).
import numpy as np, faiss, h5py, json
from path_config import data_path, output_path
K = 10; POOL = 200; NQ = 1000
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
out = {}
for name, ang in [("sift-128-euclidean", False), ("dbpedia-openai-1536-angular", True)]:
    with h5py.File(data_path(f"{name}.hdf5")) as h:
        b = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
        q = np.ascontiguousarray(h["test"][:NQ], dtype=np.float32)
    if ang: b = norm(b); q = norm(q)
    b = np.ascontiguousarray(b); q = np.ascontiguousarray(q); D = b.shape[1]
    flat = faiss.IndexFlatL2(D); flat.add(b); GTd, GT = flat.search(q, K + 1); del flat
    g = float(np.median(GTd[:, K] - GTd[:, K - 1]))
    np.save(output_path(f"kcb_base_{name}.npy"), b)
    np.save(output_path(f"kcb_q_{name}.npy"), q)
    np.save(output_path(f"kcb_g_{name}.npy"), np.array([g]))
    for tag, bb in [("sample", b[:100000]), ("full", b)]:
        idx = faiss.index_factory(D, "IVF1024,RaBitQ", faiss.METRIC_L2)
        idx.train(np.ascontiguousarray(bb[:min(len(bb), 100000)])); idx.add(np.ascontiguousarray(bb))
        faiss.extract_index_ivf(idx).nprobe = 64
        Dq, I = idx.search(q, POOL)
        errs = []
        for i in range(len(q)):
            cand = I[i]; cand = cand[cand >= 0]
            true = ((q[i] - bb[cand]) ** 2).sum(1)
            errs.append(Dq[i, :len(cand)] - true)
        s = float(np.concatenate(errs).std()); kap = s / g
        out[f"{name}|RaBitQ|{tag}"] = kap
        print(f"{name}\tRaBitQ\t{tag}\ts={s:.5f}\tg={g:.6f}\tkappa={kap:.2f}", flush=True)
        del idx
json.dump(out, open(output_path("kcb_kappa_rab.json"), "w"))
print("RABDONE", flush=True)
