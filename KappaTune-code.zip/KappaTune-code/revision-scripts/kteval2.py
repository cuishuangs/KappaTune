# Adds Bayesian-optimization baseline + parameterized k and corpus size N. Reuses kappatune core.
import numpy as np, faiss, h5py, sys
from scipy.stats import norm as snorm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
import kappatune as kt
from path_config import data_path
bpqm=kt.bpqm; build=kt.build; gt_flat=kt.gt_flat; measure_grid=kt.measure_grid; profile=kt.profile
predict_recall=kt.predict_recall; predict_latency=kt.predict_latency; spearman=kt.spearman
def norm(x): return (x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-12)).astype(np.float32)
name=sys.argv[1]; ang=bool(int(sys.argv[2])); codec=sys.argv[3]; K=int(sys.argv[4]); N=int(sys.argv[5]) if len(sys.argv)>5 else 300000
kt.K=K
with h5py.File(data_path(f"{name}.hdf5")) as h:
    b=np.ascontiguousarray(h["train"][:N],dtype=np.float32); q=np.ascontiguousarray(h["test"][:1000],dtype=np.float32)
if ang: b=norm(b); q=norm(q)
b=np.ascontiguousarray(b); q=np.ascontiguousarray(q); D=b.shape[1]; m=bpqm(D,max(8,D//8))
_f=faiss.IndexFlatL2(D); _f.add(b); GTd,GT=_f.search(q,max(100,K+1)); del _f
idx=build(b,D,codec,m)
NPR=[4,8,16,32,64,128]; LS=[10,20,50,100,200]; P=200; SEEN={4,16,64}
grid=measure_grid(b,q,GT,idx,NPR,LS,P=P); model=profile(b,q,GT,GTd,idx,[4,16,64],P=P,Ls=tuple(LS))
print(f"# {name} codec={codec} D={D} m={m} k={K} N={N} kappa={model['kappa']:.3f}",flush=True)
def e1(filt):
    pr=[];ac=[]
    for (npr,L),(rec,lat) in grid.items():
        if not filt(npr): continue
        pr.append(predict_recall(model,npr,L));ac.append(rec)
    return len(ac),float(np.abs(np.array(pr)-np.array(ac)).mean()),spearman(pr,ac)
nu,mae_u,sp_u=e1(lambda n:n not in SEEN)
print(f"E1 UNSEEN: n={nu} MAE={mae_u:.4f} Spearman={sp_u:.3f}",flush=True)
lats=sorted(set(v[1] for v in grid.values())); Tg=np.geomspace(min(lats)*1.05,max(lats)*1.2,8)
def fr(T): c=[v[0] for v in grid.values() if v[1]<=T+1e-9]; return max(c) if c else 0.0
def kt(T):
    best=None
    for npr in NPR:
        for L in LS:
            if (npr,L) in grid and predict_latency(model,npr,L)<=T:
                r=predict_recall(model,npr,L)
                if best is None or r>best[0]: best=(r,(npr,L))
    return grid[best[1]] if best else None
def onlynp(T):
    cs=[grid[(n,20)] for n in NPR if (n,20) in grid and grid[(n,20)][1]<=T]; return max(cs,key=lambda v:v[0]) if cs else None
cells=list(grid.keys()); Xc=np.array([[np.log2(n),np.log(L)] for (n,L) in cells]); Xs=(Xc-Xc.mean(0))/(Xc.std(0)+1e-9)
recs=np.array([grid[c][0] for c in cells]); lts=np.array([grid[c][1] for c in cells])
def rand(T,seed,B=6):
    rng=np.random.default_rng(seed); samp=rng.choice(len(cells),B,replace=False); cs=[grid[cells[i]] for i in samp if lts[i]<=T]; return max(cs,key=lambda v:v[0]) if cs else None
def bo(T,seed,B=6):
    rng=np.random.default_rng(seed); ev=list(rng.choice(len(cells),2,replace=False))
    while len(ev)<B:
        try:
            gr=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],recs[ev])
            gl=GaussianProcessRegressor(Matern(nu=2.5),normalize_y=True,alpha=1e-4).fit(Xs[ev],lts[ev])
            mu,sd=gr.predict(Xs,return_std=True); bst=recs[ev].max(); z=(mu-bst)/(sd+1e-9)
            ei=(mu-bst)*snorm.cdf(z)+sd*snorm.pdf(z); lp=gl.predict(Xs)
            for i in ev: ei[i]=-1e9
            ei[lp>T]=-1e9; nx=int(np.argmax(ei))
            if ei[nx]<=-1e8: break
            ev.append(nx)
        except Exception: break
    feas=[i for i in ev if lts[i]<=T]; return grid[cells[max(feas,key=lambda i:recs[i])]] if feas else None
def reg(fn):
    rs=[v for v in (fn(T) for T in Tg) if v is not None]; return 100*float(np.mean([fr(l)-r for (r,l) in rs])) if rs else float("nan")
def regT(fn):
    # regret at the TARGET budget T: gap to the best measured plan whose measured latency
    # fits T, regardless of how much of T the method actually spent
    rs=[(T,v) for T,v in ((T,fn(T)) for T in Tg) if v is not None]
    return 100*float(np.mean([fr(T)-r for T,(r,l) in rs])) if rs else float("nan")
def folk(T):
    v=grid.get((64,20)); return v if (v and v[1]<=T) else None
def rerank_first(T):
    cs=[grid[(4,L)] for L in LS if (4,L) in grid and grid[(4,L)][1]<=T]; return max(cs,key=lambda v:v[0]) if cs else None
def probe_first(T):
    cs=[grid[(n,10)] for n in NPR if (n,10) in grid and grid[(n,10)][1]<=T]; return max(cs,key=lambda v:v[0]) if cs else None
ktr=reg(kt); onr=reg(onlynp); fkr=reg(folk); rfr=reg(rerank_first); pfr=reg(probe_first)
ov=[kt(T)[1]/T for T in Tg if kt(T)]; osr=sum(1 for x in ov if x>1.0)
rnd=float(np.mean([reg(lambda T,s=s:rand(T,s)) for s in range(5)])); bor=float(np.mean([reg(lambda T,s=s:bo(T,s)) for s in range(5)]))
print(f"E2 regret(pp): kappatune={ktr:.2f}  BO(B=6)={bor:.2f}  random(B=6)={rnd:.2f}  only_nprobe={onr:.2f}  folklore={fkr:.2f}",flush=True)
ktrT=regT(kt); onrT=regT(onlynp); fkrT=regT(folk)
rndT=float(np.mean([regT(lambda T,s=s:rand(T,s)) for s in range(5)])); borT=float(np.mean([regT(lambda T,s=s:bo(T,s)) for s in range(5)]))
print(f"E2T regret@budget(pp): kappatune={ktrT:.2f}  BO(B=6)={borT:.2f}  random(B=6)={rndT:.2f}  only_nprobe={onrT:.2f}  folklore={fkrT:.2f}",flush=True)
print(f"E5 -diagnosis: rerank_first={rfr:.2f}  probe_first={pfr:.2f}",flush=True)
print(f"E2 adherence: mean(lat/T)={np.mean(ov):.2f} max={np.max(ov):.2f} overshoot={osr}/{len(ov)}",flush=True)
print("KTEVAL2DONE",flush=True)
