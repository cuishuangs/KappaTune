# BO/random regret vs evaluation budget E, answering "is BO-6 a straw man?".
# Protocol matches the existing per-budget BO baseline (kteval2/ktxlmerge): for each
# latency budget T the searcher gets E plan evaluations; we record frontier-regret at
# checkpoints E in {6,12,24,48,96} along one trajectory (5 seeds). Spaces: SMALL = the
# 30-plan IVF-PQ m=D/8 grid (ktmulti_<corpus>_PQ.json); XL = all (codec,m) jsons under
# the three memory budgets of ktxlmerge. CPU-only simulation over measured grids.
import numpy as np, json, sys, glob
from scipy.stats import norm as snorm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
from path_config import GRID_DIR

corpus = sys.argv[1]
Dxl = {"sift-128-euclidean":128, "dbpedia-openai-1536-angular":1536, "glove-100-angular":100,
       "gist-960-euclidean":960, "nytimes-256-angular":256, "deep-image-96-angular":96}[corpus]
CKPT = [6, 12, 24, 48, 96]
SEEDS = 5

def load_entries(pq_only=False):
    # SMALL space = the default-m PQ grid, which lives in ktmulti_<corpus>_PQ.json
    # (match by filename, not by m_bytes: m snaps to a divisor of D, e.g. 10 for D=100).
    pat = (str(GRID_DIR / f"ktmulti_{corpus}_PQ.json") if pq_only
           else str(GRID_DIR / f"ktmulti_{corpus}_*.json"))
    entries = []
    for f in sorted(glob.glob(pat)):
        d = json.load(open(f))
        g = {(c["npr"], c["L"]): (c["rec"], c["lat"]) for c in d["cells"]}
        mb = d.get("m_bytes")
        if mb is None:
            mb = {"PQ":Dxl//8, "OPQ":Dxl//8, "RaBitQ":Dxl//8, "ScaNN":Dxl//4, "HNSW":4*Dxl+256}[d["codec"]]
        entries.append((d["codec"], int(mb), g))
    return entries

def curves(entries, Mb, tag):
    cells = [(i, n, L) for i in range(len(entries)) for (n, L) in entries[i][2].keys()
             if entries[i][1] <= Mb]
    if not cells:
        return
    recs = np.array([entries[i][2][(n, L)][0] for (i, n, L) in cells])
    lts  = np.array([entries[i][2][(n, L)][1] for (i, n, L) in cells])
    Xc = np.array([[1.0 if entries[i][0].startswith("HNSW") else 0.0,
                    np.log2(entries[i][1]), np.log2(n), np.log(L)] for (i, n, L) in cells])
    Xs = (Xc - Xc.mean(0)) / (Xc.std(0) + 1e-9)
    Tg = np.geomspace(lts.min()*1.05, lts.max()*1.2, 8)
    def fr(T):
        c = recs[lts <= T + 1e-9]
        return c.max() if len(c) else 0.0
    def bo_traj(T, seed, E):
        rng = np.random.default_rng(seed)
        ev = list(rng.choice(len(cells), 2, replace=False)); out = {}
        while True:
            for ck in CKPT:
                if len(ev) >= ck and ck not in out:
                    feas = [j for j in ev[:ck] if lts[j] <= T]
                    out[ck] = (fr(lts[max(feas, key=lambda j: recs[j])])
                               - recs[max(feas, key=lambda j: recs[j])]) if feas else None
            if len(ev) >= E:
                break
            try:
                gr = GaussianProcessRegressor(Matern(nu=2.5), normalize_y=True, alpha=1e-4).fit(Xs[ev], recs[ev])
                gl = GaussianProcessRegressor(Matern(nu=2.5), normalize_y=True, alpha=1e-4).fit(Xs[ev], lts[ev])
                mu, sd = gr.predict(Xs, return_std=True)
                bst = recs[ev].max(); z = (mu - bst) / (sd + 1e-9)
                ei = (mu - bst)*snorm.cdf(z) + sd*snorm.pdf(z)
                lp = gl.predict(Xs)
                for j in ev: ei[j] = -1e9
                ei[lp > T] = -1e9
                nx = int(np.argmax(ei))
                if ei[nx] <= -1e8:
                    nx = int(np.random.default_rng(seed + 7*len(ev)).integers(len(cells)))
                ev.append(nx)
            except Exception:
                ev.append(int(np.random.default_rng(seed + 7*len(ev)).integers(len(cells))))
        return out
    def rand_at(T, seed, ck):
        rng = np.random.default_rng(seed)
        samp = rng.choice(len(cells), min(ck, len(cells)), replace=False)
        feas = [j for j in samp if lts[j] <= T]
        if not feas:
            return None
        jb = max(feas, key=lambda j: recs[j])
        return fr(lts[jb]) - recs[jb]
    bo_acc = {ck: [] for ck in CKPT}; rd_acc = {ck: [] for ck in CKPT}
    # BO trajectories are capped at E=48: the GP-fit cost of a per-budget trajectory grows
    # cubically in the evaluation count, and at E=96 a per-budget search on <=270 plans is
    # close to exhaustive anyway; random (cheap) still reports E=96.
    Emax = min(48, len(cells))
    for seed in range(SEEDS):
        for T in Tg:
            out = bo_traj(T, seed, Emax)
            for ck in CKPT:
                if out.get(ck) is not None:
                    bo_acc[ck].append(out[ck])
                r = rand_at(T, seed, ck)
                if r is not None:
                    rd_acc[ck].append(r)
    bom = "  ".join(f"E={ck}:{100*float(np.mean(v)):.2f}" for ck, v in bo_acc.items() if v)
    rdm = "  ".join(f"E={ck}:{100*float(np.mean(v)):.2f}" for ck, v in rd_acc.items() if v)
    print(f"{tag} plans={len(cells)} BO regret(pp) per-budget: {bom}", flush=True)
    print(f"{tag} plans={len(cells)} random regret(pp):        {rdm}", flush=True)

small = load_entries(pq_only=True)
print(f"# {corpus} BO/random regret vs evaluations (per-budget protocol, {SEEDS} seeds)", flush=True)
curves(small, 10**9, "SMALL")
xl = load_entries(pq_only=False)
for name, Mb in {"tight": int(0.19*Dxl), "mid": int(0.30*Dxl), "loose": 10**9}.items():
    curves(xl, Mb, f"XL[{name}]")
print("BOCURVEDONE", flush=True)
