# Real VDTuner end-to-end on real Milvus.
# Uses VDTuner's UNEDITED optimizer (EHVIBO botorch qEHVI + PollingBayesianOptimization round-robin
# index-type polling with successive abandonment) on its NATIVE Milvus knob space (whole_param.json,
# their KnobStand + filter_index_rule). The ONLY substitution vs their repo: the measurement backend
# is direct pymilvus (build the real Milvus index per config, load, search 1000 queries, compute
# recall@10 vs HDF5 ground truth + QPS) instead of their run_engine.sh/vector-db-benchmark wrapper.
# The 7 Milvus-yaml SYSTEM knobs are held at default (they need a per-iter Milvus restart; the 9 INDEX
# knobs, which dominate recall/QPS, are applied to real builds). We log the (recall, QPS) trajectory
# and the real tuning cost (#index builds, wall-clock) to compare against KappaTune's build-free profile.
import sys, os, time, json, numpy as np, h5py
from path_config import MILVUS_HOST, MILVUS_PORT, VDTUNER_DIR, data_path, output_path
VD = str(VDTUNER_DIR)
sys.path.insert(0, VD + "/vdtuner"); sys.path.insert(0, VD)
from pymilvus import connections, Collection, CollectionSchema, FieldSchema, DataType, utility
from optimizer_pobo_sa import PollingBayesianOptimization     # their real optimizer (unedited)
from configure import filter_index_rule                        # their real index-param rules
from utils import KnobStand                                    # their real knob scaling

CORPUS = sys.argv[1] if len(sys.argv) > 1 else "glove-100-angular"
NITER  = int(sys.argv[2]) if len(sys.argv) > 2 else 200
NQ, K = 1000, 10
KNOB_JSON = VD + "/whole_param.json"
OUT = output_path(f"vdtuner_milvus_{CORPUS}.log")

with h5py.File(data_path(f"{CORPUS}.hdf5")) as h:
    train = np.asarray(h["train"], dtype=np.float32)
    test  = np.asarray(h["test"][:NQ], dtype=np.float32)
    gt    = np.asarray(h["neighbors"][:NQ, :K])
SN = int(os.environ.get("SMOKE_N", "0"))
if SN: train = train[:SN]
metric = "IP" if "angular" in CORPUS else "L2"
if metric == "IP":
    train = train / (np.linalg.norm(train, axis=1, keepdims=True) + 1e-12)
    test  = test  / (np.linalg.norm(test,  axis=1, keepdims=True) + 1e-12)
D = int(train.shape[1])
gtset = [set(row.tolist()) for row in gt]

connections.connect(host=MILVUS_HOST, port=MILVUS_PORT)
COLL = "vdt_" + CORPUS.replace("-", "_")
if utility.has_collection(COLL): utility.drop_collection(COLL)
coll = Collection(COLL, CollectionSchema([
    FieldSchema("id", DataType.INT64, is_primary=True),
    FieldSchema("vec", DataType.FLOAT_VECTOR, dim=D)]))
print(f"[{time.strftime('%H:%M')}] inserting {len(train)} x {D} into {COLL}", flush=True)
B = 50000
for i in range(0, len(train), B):
    coll.insert([list(range(i, min(i+B, len(train)))), train[i:i+B].tolist()])
coll.flush()
print(f"[{time.strftime('%H:%M')}] inserted, entities={coll.num_entities}", flush=True)

builds = [0]; t_start = time.time(); traj = []
DIVS = [x for x in range(1, D + 1) if D % x == 0]   # valid PQ subquantizer counts (m must divide D)
def measure(index_type, bp, sp):
    if index_type == "IVF_PQ" and "m" in bp:
        bp = dict(bp); bp["m"] = min(DIVS, key=lambda x: abs(x - bp["m"]))  # Milvus requires D % m == 0
    try: coll.release()
    except Exception: pass
    try: coll.drop_index()
    except Exception: pass
    tb = time.time()
    coll.create_index("vec", {"index_type": index_type, "metric_type": metric, "params": bp})
    coll.load(); build_t = time.time() - tb; builds[0] += 1
    ts = time.time()
    res = coll.search(test.tolist(), "vec", {"metric_type": metric, "params": sp}, limit=K)
    search_t = time.time() - ts
    hit = sum(len(set(h.id for h in res[i]) & gtset[i]) for i in range(NQ))
    recall = hit / (NQ * K); qps = NQ / max(search_t, 1e-9)
    traj.append((builds[0], time.time() - t_start, recall, qps, index_type))
    open(OUT, "a").write(f"build={builds[0]} wall={time.time()-t_start:.1f}s idx={index_type} "
                         f"recall={recall:.4f} qps={qps:.1f} build_t={build_t:.2f}s sp={sp}\n")
    return qps, recall, build_t

class MilvusEnv:
    def __init__(self):
        self.knob_stand = KnobStand(KNOB_JSON)
        self.names = list(self.knob_stand.knobs_detail.keys())
    def default_conf(self):
        return [self.knob_stand.scale_forward(k, v["default"]) for k, v in self.knob_stand.knobs_detail.items()]
    def get_state(self, knob_vals_arr):
        Y = []
        for record in knob_vals_arr:
            conf = {self.names[j]: self.knob_stand.scale_back(self.names[j], v)[1] for j, v in enumerate(record)}
            idx_conf = {k: conf[k] for k in self.names[:9]}
            try:
                it, bp, sp = filter_index_rule(idx_conf)
                qps, recall, _ = measure(it, bp, sp)
            except Exception as e:
                open(OUT, "a").write(f"# measure FAIL {e}\n"); qps, recall = 1.0, 1e-4
            Y.append([qps, max(recall, 1e-4), 0.0])   # clamp so a degenerate build can't zero their per-codec normalizer
        return np.array(Y)

open(OUT, "w").write(f"# real VDTuner (botorch qEHVI + polling) on real Milvus, {CORPUS}, {NITER} iters\n")
env = MilvusEnv()
model = PollingBayesianOptimization(env, seed=1)
print(f"[{time.strftime('%H:%M')}] init_sample ({len(model.remain_types)} index types)", flush=True)
model.init_sample()
for i in range(NITER - 7):
    model.step()
    if i % 10 == 0:
        best = max(traj, key=lambda r: r[2]) if traj else None
        print(f"[{time.strftime('%H:%M')}] step {i+1}/{NITER-7} builds={builds[0]} "
              f"best_recall={best[2]:.4f}@{best[3]:.0f}qps wall={(time.time()-t_start)/60:.1f}min", flush=True)
print(f"[{time.strftime('%H:%M')}] DONE builds={builds[0]} wall={(time.time()-t_start)/60:.1f}min total", flush=True)
open(OUT, "a").write(f"# DONE builds={builds[0]} wall_min={(time.time()-t_start)/60:.1f}\n")
