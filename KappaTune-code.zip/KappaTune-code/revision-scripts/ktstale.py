# Profile staleness under ingestion: freeze codebook + centroids at N0=300K, add 10%
# then 30% held-out vectors (idx.add only, no retrain: the realistic stale-profile
# scenario), recompute exact GT per state, and measure (a) drift of the profile
# quantities (kappa, l_cg, l_bd, shallow rho(20)) and (b) the N0-chosen plans' recall
# regret on the grown corpus under the FIXED N0 cost model (isolates recall-surface
# drift; no fresh timing claims). Recall-only, multithreaded OK. Usage: ktstale.py <name> <ang>
import numpy as np, faiss, h5py, sys
from kappatune import bpqm, measure_grid, predict_latency, predict_recall, profile
from path_config import data_path
K = 10
name = sys.argv[1]; ang = bool(int(sys.argv[2]))
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
with h5py.File(data_path(f"{name}.hdf5")) as h:
    ball = np.ascontiguousarray(h["train"][:390000], dtype=np.float32)
    q = np.ascontiguousarray(h["test"][:1000], dtype=np.float32)
if ang: ball = norm(ball); q = norm(q)
ball = np.ascontiguousarray(ball); q = np.ascontiguousarray(q)
N0 = 300000; D = ball.shape[1]; m = bpqm(D, max(8, D // 8))
idx = faiss.index_factory(D, f"IVF1024,PQ{m}", faiss.METRIC_L2)
idx.train(ball[:100000]); idx.add(ball[:N0])
NPR = [4, 8, 16, 32, 64, 128]; LS = [10, 20, 50, 100, 200]; P = 200
def kt_plan(model, T):
    best = None
    for npr in NPR:
        for L in LS:
            if predict_latency(model, npr, L) <= T:
                r = predict_recall(model, npr, L)
                if best is None or r > best[0]: best = (r, (npr, L))
    return best[1] if best else None
def state(bcur):
    f = faiss.IndexFlatL2(D); f.add(bcur); GTd, GT = f.search(q, 100); del f
    grid = measure_grid(bcur, q, GT, idx, NPR, LS, P=P, reps=1)
    model = profile(bcur, q, GT, GTd, idx, [4, 16, 64], P=P, Ls=tuple(LS), reps=1)
    lcg = 1 - model["rcv"][1]; lbd = model["rcv"][1] - model["rrv"][1]
    return grid, model, lcg, lbd
print(f"# {name} D={D} m={m} N0={N0}, frozen codebook+centroids, inject +10%/+30%", flush=True)
grid0, model0, lcg0, lbd0 = state(ball[:N0])
lats = sorted(set(v[1] for v in grid0.values())); Tg = np.geomspace(min(lats) * 1.05, max(lats) * 1.2, 8)
plans0 = {T: kt_plan(model0, T) for T in Tg}
print(f"STATE +0%:  kappa={model0['kappa']:.2f} lcg={lcg0:.3f} lbd={lbd0:.3f} rho20={model0['rho'][20]:.3f}", flush=True)
for frac, N1 in [(10, 330000), (30, 390000)]:
    idx.add(ball[idx.ntotal:N1])
    grid1, model1, lcg1, lbd1 = state(ball[:N1])
    # (b) stale-plan regret under the FIXED N0 cost model: feasibility judged by model0's
    # latency prediction on both sides, recalls from the grown corpus.
    regs = []; overlap = 0; nT = 0
    m1 = dict(model1); m1["c0"] = model0["c0"]; m1["c_probe"] = model0["c_probe"]
    m1["c_rerank"] = model0["c_rerank"]; m1["lat_scale"] = model0["lat_scale"]
    for T in Tg:
        p0 = plans0[T]
        if p0 is None: continue
        nT += 1
        feas = [(n, L) for n in NPR for L in LS if predict_latency(model0, n, L) <= T]
        best1 = max(grid1[c][0] for c in feas)
        regs.append(best1 - grid1[p0][0])
        if kt_plan(m1, T) == p0: overlap += 1
    print(f"STATE +{frac}%: kappa={model1['kappa']:.2f} lcg={lcg1:.3f} lbd={lbd1:.3f} "
          f"rho20={model1['rho'][20]:.3f} stale_plan_regret={100*np.mean(regs):.2f}pp "
          f"replan_overlap={overlap}/{nT}", flush=True)
print("STALEDONE", flush=True)
