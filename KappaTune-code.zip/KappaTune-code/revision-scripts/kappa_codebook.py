# Codebook-only kappa probe: is kappa a property of the QUANTIZER CODEBOOK rather than
# the built index? If yes, an untested codec's kappa (hence Phi(kappa) boundary loss) is
# measurable by training its codebook on a sample and re-encoding the REFERENCE index's
# cached pool members: cost O(sample + pools), independent of corpus size N, with no
# index build (no add over N vectors) and no search pass for the candidate codec.
# Per point we report kappa_full (the codec's own built index + search, as in kappa.py)
# vs kappa_cb (codebook + reference pools), measured lbd, and the wall-clock of each
# probe. Summary: agreement (Spearman, median rel-err) and Phi-prediction RMSE under
# both kappa versions. Validation set mirrors the kappa collapse points (PQ/OPQ).
import numpy as np, faiss, h5py, time
from scipy.optimize import curve_fit
from path_config import DATA_DIR, data_path

K = 10; POOL = 200; NQ = 1000; TRAIN = 50000
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
def snap_m(D, t):
    m = t
    while D % m != 0 and m > 1: m -= 1
    return m

def corpus_ctx(b, q):
    """GT + reference IVF-PQ pools, shared by all codecs probed on this (corpus, D)."""
    b = np.ascontiguousarray(b, np.float32); q = np.ascontiguousarray(q, np.float32)
    D = b.shape[1]
    flat = faiss.IndexFlatL2(D); flat.add(b); GTd, GT = flat.search(q, 100); del flat
    mref = snap_m(D, max(8, D // 8))
    ref = faiss.index_factory(D, f"IVF1024,PQ{mref}", faiss.METRIC_L2)
    ref.train(b[:min(len(b), TRAIN)]); ref.add(b)
    faiss.extract_index_ivf(ref).nprobe = 64
    _, Iref = ref.search(q, POOL); del ref
    g = float(np.median(GTd[:, K] - GTd[:, K - 1]))
    return dict(b=b, q=q, D=D, GT=GT, GTd=GTd, Iref=Iref, g=g)

def full_probe(ctx, quant, m):
    """Build the codec's own index (train+add+search): kappa_full and measured lbd."""
    b, q, D = ctx["b"], ctx["q"], ctx["D"]
    t0 = time.perf_counter()
    fac = f"OPQ{m},IVF1024,PQ{m}" if quant == "OPQ" else f"IVF1024,PQ{m}"
    idx = faiss.index_factory(D, fac, faiss.METRIC_L2)
    idx.train(b[:min(len(b), TRAIN)]); idx.add(b)
    faiss.extract_index_ivf(idx).nprobe = 64
    Dq, I = idx.search(q, POOL)
    gts = [set(ctx["GT"][i, :K].tolist()) for i in range(len(q))]
    def rr(L): return float(np.mean([len(gts[i] & set(I[i, :L].tolist())) / K for i in range(len(q))]))
    lbd = rr(POOL) - rr(K)
    errs = []
    for i in range(len(q)):
        cand = I[i]; cand = cand[cand >= 0]
        true = ((q[i] - b[cand]) ** 2).sum(1)
        errs.append(Dq[i, :len(cand)] - true)
    s = float(np.concatenate(errs).std())
    t = time.perf_counter() - t0
    del idx
    return s, lbd, t

def codebook_probe(ctx, quant, m):
    """Train codebook only (no add, no search); re-encode reference pool members."""
    b, q, D, Iref = ctx["b"], ctx["q"], ctx["D"], ctx["Iref"]
    t0 = time.perf_counter()
    fac = f"OPQ{m},IVF1024,PQ{m}" if quant == "OPQ" else f"IVF1024,PQ{m}"
    idx = faiss.index_factory(D, fac, faiss.METRIC_L2)
    idx.train(b[:min(len(b), TRAIN)])            # codebook training only; idx.ntotal stays 0
    uniq = np.unique(Iref[Iref >= 0])
    codes = idx.sa_encode(np.ascontiguousarray(b[uniq]))
    recon = idx.sa_decode(codes)
    pos = np.full(int(uniq.max()) + 1, -1, dtype=np.int64); pos[uniq] = np.arange(len(uniq))
    errs = []
    for i in range(len(q)):
        cand = Iref[i]; cand = cand[cand >= 0]
        rv = recon[pos[cand]]
        dq = ((q[i] - rv) ** 2).sum(1)
        dt = ((q[i] - b[cand]) ** 2).sum(1)
        errs.append(dq - dt)
    s = float(np.concatenate(errs).std())
    t = time.perf_counter() - t0
    del idx
    return s, t

results = []
def point(tag, ctx, quant, m):
    s_f, lbd, t_f = full_probe(ctx, quant, m)
    s_c, t_c = codebook_probe(ctx, quant, m)
    g = ctx["g"]
    kf = s_f / g if g > 0 else float("nan")
    kc = s_c / g if g > 0 else float("nan")
    results.append((tag, quant, ctx["D"], lbd, kf, kc, t_f, t_c))
    print(f"{tag}\t{quant}\tD={ctx['D']}\tm={m}\tlbd={lbd:.4f}\tkappa_full={kf:.2f}\tkappa_cb={kc:.2f}\t"
          f"t_full={t_f:.1f}s\tt_cb={t_c:.1f}s", flush=True)

DATA = DATA_DIR
# --- mxbai prefix-truncation family (OPQ) + one PQ point ---
B = np.load(data_path("mxbai_base.npy")); Q = np.load(data_path("mxbai_q.npy"))
for D in [64, 128, 256, 512, 768, 1024]:
    ctx = corpus_ctx(norm(B[:, :D]), norm(Q[:NQ, :D]))
    point("mxbai", ctx, "OPQ", D // 8)
    if D == 512:
        point("mxbai", ctx, "PQ", 64)
del B, Q
# --- bge PCA-truncation family (OPQ), kappa2.py conventions ---
E = np.load(data_path("bge_emb.npy"))
perm = np.random.default_rng(0).permutation(len(E))
base = np.ascontiguousarray(E[perm[:-2000]]); queries = np.ascontiguousarray(E[perm[-2000:]])
samp = base[np.random.default_rng(1).choice(len(base), min(len(base), 80000), replace=False)].astype(np.float64)
mean = samp.mean(0); C = ((samp - mean).T @ (samp - mean)) / len(samp)
ev, evec = np.linalg.eigh(C); W = evec[:, ::-1]
for D in [256, 512, 1024]:
    bb = norm(((base - mean) @ W[:, :D]).astype(np.float32))
    qq = norm(((queries[:NQ] - mean) @ W[:, :D]).astype(np.float32))
    ctx = corpus_ctx(bb, qq)
    point("bge-pca", ctx, "OPQ", D // 8)
del E, base, queries
# --- hdf5 corpora ---
H = [("sift-128-euclidean", False, ["PQ", "OPQ"]), ("dbpedia-openai-1536-angular", True, ["PQ"]),
     ("glove-100-angular", True, ["PQ"]), ("deep-image-96-angular", True, ["PQ"]),
     ("gist-960-euclidean", False, ["PQ"]), ("mnist-784-euclidean", False, ["PQ"]),
     ("fashion-mnist-784-euclidean", False, ["PQ"])]
for nm, ang, quants in H:
    with h5py.File(DATA / f"{nm}.hdf5") as h:
        bb = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
        qq = np.ascontiguousarray(h["test"][:NQ], dtype=np.float32)
    if ang: bb = norm(bb); qq = norm(qq)
    D = bb.shape[1]; m = snap_m(D, max(8, D // 8))
    ctx = corpus_ctx(bb, qq)
    for qn in quants:
        try: point(nm, ctx, qn, m)
        except Exception as e: print(f"# {nm} {qn} ERR {e}", flush=True)

# --- summary ---
ok = [r for r in results if np.isfinite(r[4]) and np.isfinite(r[5])]
lbd = np.array([r[3] for r in ok]); kf = np.array([r[4] for r in ok]); kc = np.array([r[5] for r in ok])
def spearman(a, b):
    ra = np.argsort(np.argsort(a)); rb = np.argsort(np.argsort(b)); n = len(a)
    return 1 - 6 * np.sum((ra - rb) ** 2) / (n * (n * n - 1))
rel = np.abs(kc - kf) / np.maximum(kf, 1e-9)
phi = lambda k, a, tau: a * (1 - np.exp(-k / tau))
def fit_rmse(kv):
    try:
        p, _ = curve_fit(phi, kv, lbd, p0=[0.56, 22.0], maxfev=10000)
        return float(np.sqrt(np.mean((phi(kv, *p) - lbd) ** 2))), p
    except Exception:
        return float("nan"), (np.nan, np.nan)
rf, pf = fit_rmse(kf); rc, pc = fit_rmse(kc)
print(f"SUMMARY n={len(ok)} Spearman(kappa_cb,kappa_full)={spearman(kc,kf):.3f} "
      f"median_rel_err={np.median(rel):.3f} max_rel_err={rel.max():.3f}", flush=True)
print(f"SUMMARY Phi fit RMSE: kappa_full={rf:.4f} (a={pf[0]:.3f},tau={pf[1]:.1f})  "
      f"kappa_cb={rc:.4f} (a={pc[0]:.3f},tau={pc[1]:.1f})", flush=True)
tf = np.array([r[6] for r in ok]); tc = np.array([r[7] for r in ok])
print(f"SUMMARY probe cost: full build+search mean={tf.mean():.1f}s  codebook-only mean={tc.mean():.1f}s  "
      f"speedup={tf.mean()/max(tc.mean(),1e-9):.1f}x (at 300K; the full probe scales with N, the codebook probe does not)", flush=True)
print("KCBDONE", flush=True)
