# KappaTune: cost-based execution optimizer for quantized ANN.
# E1 (cost-model accuracy) + E2 (tuner vs baselines) + E3 (tuning cost), one corpus+codec.
import numpy as np, faiss, h5py, time, sys
from path_config import data_path
K=10
def norm(x): return (x/(np.linalg.norm(x,axis=1,keepdims=True)+1e-12)).astype(np.float32)
def bpqm(D,t):
    b=1
    for m in range(1,D+1):
        if D%m==0 and abs(m-t)<abs(b-t): b=m
    return b
def load(name,ang,N=300000,NQ=1000):
    with h5py.File(data_path(f"{name}.hdf5")) as h:
        b=np.ascontiguousarray(h["train"][:N],dtype=np.float32); q=np.ascontiguousarray(h["test"][:NQ],dtype=np.float32)
    if ang: b=norm(b); q=norm(q)
    return np.ascontiguousarray(b),np.ascontiguousarray(q)
def build(b,D,codec,m,nlist=1024):
    fac={"PQ":f"IVF{nlist},PQ{m}","OPQ":f"OPQ{m},IVF{nlist},PQ{m}"}[codec]
    idx=faiss.index_factory(D,fac,faiss.METRIC_L2); idx.train(b[:min(len(b),100000)]); idx.add(b); return idx
def gt_flat(b,q,D):
    f=faiss.IndexFlatL2(D); f.add(b); GTd,GT=f.search(q,100); del f; return GTd,GT
def topk_recall(I,tk_order,gts,nq):  # unused helper placeholder
    pass

# ---------- ground-truth grid: actual (recall, latency_ms) per (nprobe,L) ----------
# Refinement is PREFIX-ONLY (sec 2 / prop:topL-monotone): exact distances for the top-L
# pool members, return the K smallest AMONG THE REFINED L (never a mixed exact+quantized
# sort, which is the harmful mixing of sec 7). At L=K this equals the no-rerank baseline.
def topk_prefix(I,ex,L):
    if L<=K: return I[:,:K]
    ordr=np.argpartition(ex,K,axis=1)[:,:K]
    return np.take_along_axis(I[:,:L],ordr,axis=1)
def measure_grid(b,q,GT,idx,nprobes,Ls,P=200,reps=3):
    nq=len(q); gts=[set(GT[i,:K].tolist()) for i in range(nq)]; ivf=faiss.extract_index_ivf(idx); cells={}
    for npr in nprobes:
        ivf.nprobe=npr
        ts=[]
        for r in range(reps):
            t0=time.perf_counter(); Dq,I=idx.search(q,P); ts.append((time.perf_counter()-t0)/nq*1000)
        search_ms=min(ts)
        for L in Ls:
            if L>P: continue
            tr=[]
            for r in range(reps):
                t0=time.perf_counter()
                cand=np.clip(I[:,:L],0,len(b)-1); vecs=b[cand.reshape(-1)].reshape(nq,L,-1)
                ex=((q[:,None,:]-vecs)**2).sum(-1)
                tk=topk_prefix(I,ex,L)
                tr.append((time.perf_counter()-t0)/nq*1000)
            rec=float(np.mean([len(gts[i]&set(tk[i].tolist()))/K for i in range(nq)]))
            cells[(npr,L)]=(rec,search_ms+min(tr))
    return cells

# ---------- cheap profile -> cost model ----------
def profile(b,q,GT,GTd,idx,nprobes_prof,P=200,Ls=(10,20,50,100,200),reps=3):
    nq=len(q); gts=[set(GT[i,:K].tolist()) for i in range(nq)]; ivf=faiss.extract_index_ivf(idx)
    Rraw={}; Rceil={}; cache=None; nsearch=0; tsearch={}
    ref=nprobes_prof[len(nprobes_prof)//2]
    for npr in nprobes_prof:
        ivf.nprobe=npr
        t0=time.perf_counter(); Dq,I=idx.search(q,P); tsearch[npr]=(time.perf_counter()-t0)/nq*1000; nsearch+=1
        def rr(L): return float(np.mean([len(gts[i]&set(I[i,:L].tolist()))/K for i in range(nq)]))
        Rraw[npr]=rr(K); Rceil[npr]=rr(P)
        if npr==ref:
            cand=np.clip(I,0,len(b)-1); vecs=b[cand.reshape(-1)].reshape(nq,P,-1)
            dex=((q[:,None,:]-vecs)**2).sum(-1); cache=(I.copy(),Dq.copy().astype(np.float32),dex)
    # recovery fraction rho(L) from cached pool (numpy replay, no search; prefix-only)
    I0,Dq0,dex0=cache; lbd0=Rceil[ref]-Rraw[ref]; rho={}
    for L in Ls:
        tk=topk_prefix(I0,dex0[:,:L],L)
        recL=float(np.mean([len(gts[i]&set(tk[i].tolist()))/K for i in range(nq)]))
        rho[L]=(recL-Rraw[ref])/lbd0 if lbd0>1e-9 else 1.0
    # kappa
    s=float((Dq0-dex0).std()); g=float(np.median(GTd[:,K]-GTd[:,K-1])); kappa=s/g if g>0 else float("nan")
    # latency coeffs: c_rerank from rerank timing at 2 L on cached pool; c_probe,c0 from search at 2 nprobe
    def rerank_time(L):
        tr=[]
        for r in range(reps):
            t0=time.perf_counter()
            cand=np.clip(I0[:,:L],0,len(b)-1); vecs=b[cand.reshape(-1)].reshape(nq,L,-1)
            ex=((q[:,None,:]-vecs)**2).sum(-1)
            topk_prefix(I0,ex,L)
            tr.append((time.perf_counter()-t0)/nq*1000)
        return min(tr)
    Llo,Lhi=Ls[0],Ls[-1]; rlo,rhi=rerank_time(Llo),rerank_time(Lhi); c_rerank=(rhi-rlo)/(Lhi-Llo)
    def stime(npr,r=reps):
        ivf.nprobe=npr; ts=[]
        for _ in range(r):
            t0=time.perf_counter(); idx.search(q,P); ts.append((time.perf_counter()-t0)/len(q)*1000)
        return min(ts)
    nlo,nhi=nprobes_prof[0],nprobes_prof[-1]; slo,shi=stime(nlo),stime(nhi); c_probe=(shi-slo)/(nhi-nlo)
    c0=slo-c_probe*nlo + (rlo-c_rerank*Llo)
    # de-bias the linear model to the min-of-reps actual at the reference nprobe (closes conservative gap)
    sref=stime(ref)
    pa=[(sref+rerank_time(L))/max(c0+c_probe*ref+c_rerank*L,1e-9) for L in (Llo,Lhi)]
    lat_scale=float(np.median(pa))*1.10
    # interpolators over profiled nprobe (in log2)
    xs=np.log2(np.array(nprobes_prof,dtype=float)); rrv=np.array([Rraw[n] for n in nprobes_prof]); rcv=np.array([Rceil[n] for n in nprobes_prof])
    return dict(xs=xs,rrv=rrv,rcv=rcv,rho=rho,kappa=kappa,s=s,g=g,c0=c0,c_probe=c_probe,c_rerank=c_rerank,lat_scale=lat_scale,nsearch=nsearch,Ls=list(Ls))
def pr_raw(model,npr): return float(np.interp(np.log2(npr),model["xs"],model["rrv"]))
def pr_ceil(model,npr): return float(np.interp(np.log2(npr),model["xs"],model["rcv"]))
def predict_recall(model,npr,L):
    rr=pr_raw(model,npr); rc=pr_ceil(model,npr); Ls=model["Ls"]; rL=np.interp(L,Ls,[model["rho"][l] for l in Ls])
    return rr+float(rL)*(rc-rr)
def predict_latency(model,npr,L): return model.get("lat_scale",1.0)*(model["c0"]+model["c_probe"]*npr+model["c_rerank"]*L)

def spearman(a,b):
    a=np.asarray(a); b=np.asarray(b); ra=np.argsort(np.argsort(a)); rb=np.argsort(np.argsort(b)); n=len(a)
    return 1-6*np.sum((ra-rb)**2)/(n*(n*n-1))

def main():
    name=sys.argv[1]; ang=bool(int(sys.argv[2])); codec=sys.argv[3] if len(sys.argv)>3 else "PQ"
    b,q=load(name,ang); D=b.shape[1]; m=bpqm(D,max(8,D//8))
    GTd,GT=gt_flat(b,q,D)
    idx=build(b,D,codec,m)
    NPR=[4,8,16,32,64,128]; LS=[10,20,50,100,200]; P=200
    grid=measure_grid(b,q,GT,idx,NPR,LS,P=P)
    model=profile(b,q,GT,GTd,idx,[4,16,64],P=P,Ls=tuple(LS))
    print(f"# {name} codec={codec} D={D} m={m} kappa={model['kappa']:.3f} "
          f"lat_coef c0={model['c0']:.4f} cp={model['c_probe']:.5f} cr={model['c_rerank']:.5f}",flush=True)
    # ---- E1 cost-model accuracy ----
    pr=[]; ac=[]; plat=[]; alat=[]
    for (npr,L),(rec,lat) in grid.items():
        pr.append(predict_recall(model,npr,L)); ac.append(rec); plat.append(predict_latency(model,npr,L)); alat.append(lat)
    pr=np.array(pr); ac=np.array(ac); plat=np.array(plat); alat=np.array(alat)
    print(f"E1 n={len(ac)} recall_MAE={np.abs(pr-ac).mean():.4f} recall_Spearman={spearman(pr,ac):.3f} "
          f"lat_MAPE={np.mean(np.abs(plat-alat)/np.maximum(alat,1e-6)):.3f}",flush=True)
    # ---- E2 tuner vs baselines (frontier-regret) + E3 tuning cost ----
    def frontier_at(lat):
        c=[v[0] for v in grid.values() if v[1]<=lat+1e-9]; return max(c) if c else 0.0
    lats=sorted(set(v[1] for v in grid.values())); Tgrid=np.geomspace(min(lats)*1.05,max(lats),8)
    kt_pts=[]; kt_over=[]
    for T in Tgrid:
        best=None
        for npr in NPR:
            for L in LS:
                if (npr,L) in grid and predict_latency(model,npr,L)<=T:
                    r=predict_recall(model,npr,L)
                    if best is None or r>best[0]: best=(r,(npr,L))
        if best:
            rec,lat=grid[best[1]]; kt_pts.append((lat,rec)); kt_over.append(lat/T)
    # only-nprobe baseline: sweep nprobe at L=20 (its natural operating points)
    on_pts=[grid[(npr,20)] for npr in NPR if (npr,20) in grid]; on_pts=[(l,r) for (r,l) in [(v[0],v[1]) for v in on_pts]]
    on_pts=[(grid[(npr,20)][1],grid[(npr,20)][0]) for npr in NPR if (npr,20) in grid]
    fk=grid[(64,20)]; fk_pt=(fk[1],fk[0])
    # E5 -diagnosis ablations: fixed policies that ignore the cg/bd split
    def rerank_first(T):   # always deepen L (fix nprobe=16), ignore diagnosis
        cs=[grid[(16,L)] for L in LS if (16,L) in grid and grid[(16,L)][1]<=T]; 
        return max(cs,key=lambda v:v[0]) if cs else None
    def probe_first(T):    # always raise nprobe (no rerank, L=k=10)
        cs=[grid[(npr,10)] for npr in NPR if (npr,10) in grid and grid[(npr,10)][1]<=T]
        return max(cs,key=lambda v:v[0]) if cs else None
    rf_pts=[(v[1],v[0]) for v in (rerank_first(T) for T in Tgrid) if v]
    pf_pts=[(v[1],v[0]) for v in (probe_first(T) for T in Tgrid) if v]
    def mean_reg(pts): return 100*np.mean([frontier_at(l)-r for (l,r) in pts]) if pts else float("nan")
    print("E2 mean frontier-regret (pp, lower=better, 0=on Pareto frontier):",flush=True)
    print(f"   kappatune={mean_reg(kt_pts):.2f}  only_nprobe={mean_reg(on_pts):.2f}  folklore(fixed 64/20)={mean_reg([fk_pt]):.2f}",flush=True)
    print(f"E5 -diagnosis ablation frontier-regret (pp): rerank_first={mean_reg(rf_pts):.2f}  probe_first={mean_reg(pf_pts):.2f}  (KappaTune uses the cg/bd diagnosis to pick correctly on both regimes)",flush=True)
    print(f"   kappatune budget-adherence (actual_lat/T, ~1 good, >1 overshoot): mean={np.mean(kt_over):.2f} max={np.max(kt_over):.2f}",flush=True)
    print("   kappatune deployed points (lat_ms, recall):", [(round(l,3),round(r,3)) for l,r in kt_pts],flush=True)
    print(f"E3 tuning_cost: kappatune={model['nsearch']} profile searches +1 build  vs  full grid {len(grid)} cells +1 build  -> {len(grid)/model['nsearch']:.1f}x fewer search-rerank evals",flush=True)
    print("KTDONE",flush=True)
if __name__ == "__main__":
    main()
