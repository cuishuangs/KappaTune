# Reprice the XL grids for the SSD-resident raw-store regime: every exact distance in a
# quantized plan pays the measured O_DIRECT per-fetch cost (rev3_cl.json) instead of a
# RAM gather: lat' = lat + L * (c_SSD - c_RAM). Applies to all quantized codecs,
# including ScaNN-AH, whose internal reorder fetches raw vectors too (its RAM-fetch term
# is <0.3% of the SSD cost, disclosed). HNSW keeps its vectors in RAM inside M(pi) and
# performs no refinement fetch: unchanged. Originals untouched; output to ssd/ with the
# same filenames so the sims can switch via GRIDDIR.
import json, glob, os
from path_config import GRID_DIR, output_path, ssd_grid_path
CL = json.load(open(output_path("rev3_cl.json")))
n = 0
for f in sorted(glob.glob(str(GRID_DIR / "ktmulti_*.json"))):
    d = json.load(open(f)); corpus = d.get("corpus")
    if corpus not in CL:
        continue
    if not d["codec"].startswith("HNSW"):
        dc = (CL[corpus]["us_disk"] - CL[corpus]["us_ram"]) / 1000.0  # ms per exact distance
        for c in d["cells"]:
            c["lat"] = c["lat"] + c["L"] * dc
        d["repriced_ssd"] = True
    json.dump(d, open(ssd_grid_path(os.path.basename(f)), "w"))
    n += 1
print(f"repriced {n} grids -> ssd/", flush=True)
print("REPRICEDONE", flush=True)
