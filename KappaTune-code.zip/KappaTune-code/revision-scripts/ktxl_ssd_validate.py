# Third validation layer for the SSD repricing: measure one corpus's (nprobe,L) grid
# END TO END with actual O_DIRECT reranks and compare per-cell latency against the
# repriced json (ssd/ktmulti_*.json). Usage: ktxl_ssd_validate.py <corpus> <ang> <codec> [MDIV]
# Run PQ variants under system python and RaBitQ under vrab. NQ=250, reps=2 (validation
# protocol; rerank dominates the cells under SSD pricing so the smaller NQ is adequate).
import numpy as np, h5py, faiss, time, os, mmap, json, sys
from path_config import data_path, ssd_grid_path, work_path
K = 10; NPR = [4, 8, 16, 32, 64, 128]; LS = [10, 20, 50, 100, 200]; P = 200; NQ = 250; reps = 2
BLK = 4096
corpus = sys.argv[1]; ang = bool(int(sys.argv[2])); codec = sys.argv[3]
MDIV = int(sys.argv[4]) if len(sys.argv) > 4 else 8
def norm(x): return (x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)).astype(np.float32)
def bpqm(D, t):
    bb = 1
    for mm in range(1, D + 1):
        if D % mm == 0 and abs(mm - t) < abs(bb - t): bb = mm
    return bb
with h5py.File(data_path(f"{corpus}.hdf5")) as h:
    b = np.ascontiguousarray(h["train"][:300000], dtype=np.float32)
    q = np.ascontiguousarray(h["test"][:NQ], dtype=np.float32)
if ang: b = norm(b); q = norm(q)
b = np.ascontiguousarray(b); q = np.ascontiguousarray(q); D = b.shape[1]
m = bpqm(D, max(4, D // MDIV)); nq = len(q)
RAW = work_path(f"rawstore_val_{corpus}.bin")
b.tofile(RAW); fd0 = os.open(RAW, os.O_RDONLY); os.fsync(fd0); os.close(fd0)
fd = os.open(RAW, os.O_RDONLY | os.O_DIRECT); row = 4 * D
span = ((row // BLK) + 2) * BLK; buf = mmap.mmap(-1, span); mv = memoryview(buf)
def fetch(i, outv):
    off = i * row; a = (off // BLK) * BLK; e = -(-(off + row) // BLK) * BLK
    os.preadv(fd, [mv[:e - a]], a)
    outv[:] = np.frombuffer(mv[off - a:off - a + row], dtype=np.float32)
tmp = np.empty(D, dtype=np.float32); fetch(777, tmp); assert np.allclose(tmp, b[777])
fac = {"PQ": f"IVF1024,PQ{m}", "RaBitQ": "IVF1024,RaBitQ"}[codec]
idx = faiss.index_factory(D, fac, faiss.METRIC_L2)
idx.train(b[:100000]); idx.add(b); ivf = faiss.extract_index_ivf(idx)
tag = codec if MDIV == 8 else f"{codec}m{m}"
ref = json.load(open(ssd_grid_path(f"ktmulti_{corpus}_{tag}.json")))
refg = {(c["npr"], c["L"]): c["lat"] for c in ref["cells"]}
devs = []
V = None
for npr in NPR:
    ivf.nprobe = npr; ss = []
    for _ in range(3):
        t0 = time.perf_counter(); Dq, I = idx.search(q, P); ss.append((time.perf_counter() - t0) / nq * 1000)
    sm = min(ss)
    for L in LS:
        if V is None or V.shape[0] < L:
            V = np.empty((L, D), dtype=np.float32)
        best = None
        for _ in range(reps):
            t0 = time.perf_counter()
            for i in range(nq):
                ids = I[i, :L]
                for j in range(L):
                    fetch(int(ids[j]) if ids[j] >= 0 else 0, V[j])
                ex = ((q[i] - V[:L]) ** 2).sum(1)
                if L > K:
                    np.argpartition(ex, K)[:K]
            ms = (time.perf_counter() - t0) / nq * 1000
            best = ms if best is None else min(best, ms)
        meas = sm + best; pred = refg[(npr, L)]
        dev = (pred - meas) / meas
        devs.append(dev)
        print(f"{tag} npr={npr} L={L}: measured={meas:.2f}ms repriced={pred:.2f}ms dev={100*dev:+.1f}%", flush=True)
devs = np.array(devs)
print(f"SUMMARY {corpus} {tag}: mean|dev|={100*np.mean(np.abs(devs)):.1f}% max|dev|={100*np.max(np.abs(devs)):.1f}%", flush=True)
os.close(fd); os.remove(RAW)
print("VALDONE", flush=True)
