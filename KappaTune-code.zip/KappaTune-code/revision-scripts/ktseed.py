# IVF-clustering seed robustness: rebuild the index under three different clustering
# seeds (seed-permuted training subset + faiss ClusteringParameters seed where exposed)
# and rerun the kteval2 protocol per seed. GT is computed once per corpus (seed-free).
# TIMED: run alone, OMP_NUM_THREADS=1, sequential. Usage: ktseed.py <name> <ang>
import numpy as np, faiss, sys
from scipy.stats import norm as snorm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
from kappatune import bpqm, gt_flat, load, measure_grid, predict_latency, predict_recall, profile, spearman
K = 10
name = sys.argv[1]; ang = bool(int(sys.argv[2]))
b, q = load(name, ang); D = b.shape[1]; m = bpqm(D, max(8, D // 8))
GTd, GT = gt_flat(b, q, D)
NPR = [4, 8, 16, 32, 64, 128]; LS = [10, 20, 50, 100, 200]; P = 200; SEEN = {4, 16, 64}
print(f"# {name} D={D} m={m} seeds=0,1,2 (permuted 100K training subset + cp.seed)", flush=True)
for seed in (0, 1, 2):
    rng = np.random.default_rng(seed)
    tr = np.ascontiguousarray(b[rng.permutation(len(b))[:100000]])
    idx = faiss.index_factory(D, f"IVF{1024},PQ{m}", faiss.METRIC_L2)
    try:
        faiss.extract_index_ivf(idx).cp.seed = 7919 * seed + 1234
    except Exception:
        pass
    idx.train(tr); idx.add(b)
    grid = measure_grid(b, q, GT, idx, NPR, LS, P=P)
    model = profile(b, q, GT, GTd, idx, [4, 16, 64], P=P, Ls=tuple(LS))
    pr = []; ac = []
    for (npr, L), (rec, lat) in grid.items():
        if npr in SEEN: continue
        pr.append(predict_recall(model, npr, L)); ac.append(rec)
    mae = float(np.abs(np.array(pr) - np.array(ac)).mean()); sp = spearman(pr, ac)
    lats = sorted(set(v[1] for v in grid.values())); Tg = np.geomspace(min(lats) * 1.05, max(lats) * 1.2, 8)
    def fr(T):
        c = [v[0] for v in grid.values() if v[1] <= T + 1e-9]; return max(c) if c else 0.0
    def kt(T):
        best = None
        for npr in NPR:
            for L in LS:
                if (npr, L) in grid and predict_latency(model, npr, L) <= T:
                    r = predict_recall(model, npr, L)
                    if best is None or r > best[0]: best = (r, (npr, L))
        return grid[best[1]] if best else None
    pts = [(T, kt(T)) for T in Tg]; pts = [(T, v) for T, v in pts if v]
    ktr = 100 * float(np.mean([fr(l) - r for _, (r, l) in pts]))
    adh = [l / T for T, (r, l) in pts]; osr = sum(1 for x in adh if x > 1.0)
    cells = list(grid.keys()); Xc = np.array([[np.log2(n), np.log(L)] for (n, L) in cells])
    Xs = (Xc - Xc.mean(0)) / (Xc.std(0) + 1e-9)
    recs = np.array([grid[c][0] for c in cells]); lts = np.array([grid[c][1] for c in cells])
    def rand6(T, sd):
        r2 = np.random.default_rng(sd); samp = r2.choice(len(cells), 6, replace=False)
        cs = [grid[cells[i]] for i in samp if lts[i] <= T]; return max(cs, key=lambda v: v[0]) if cs else None
    def bo6(T, sd):
        r2 = np.random.default_rng(sd); ev = list(r2.choice(len(cells), 2, replace=False))
        while len(ev) < 6:
            try:
                gr = GaussianProcessRegressor(Matern(nu=2.5), normalize_y=True, alpha=1e-4).fit(Xs[ev], recs[ev])
                gl = GaussianProcessRegressor(Matern(nu=2.5), normalize_y=True, alpha=1e-4).fit(Xs[ev], lts[ev])
                mu, sd_ = gr.predict(Xs, return_std=True); bst = recs[ev].max(); z = (mu - bst) / (sd_ + 1e-9)
                ei = (mu - bst) * snorm.cdf(z) + sd_ * snorm.pdf(z); lp = gl.predict(Xs)
                for i in ev: ei[i] = -1e9
                ei[lp > T] = -1e9; nx = int(np.argmax(ei))
                if ei[nx] <= -1e8: break
                ev.append(nx)
            except Exception: break
        feas = [i for i in ev if lts[i] <= T]
        return grid[cells[max(feas, key=lambda i: recs[i])]] if feas else None
    def reg(fn):
        out = []
        for sd in range(5):
            rs = [v for v in (fn(T, sd) for T in Tg) if v is not None]
            if rs: out.append(np.mean([fr(l) - r for (r, l) in rs]))
        return 100 * float(np.mean(out)) if out else float("nan")
    print(f"SEED {seed}: kappa={model['kappa']:.3f} E1_Spearman={sp:.3f} MAE={mae:.4f} "
          f"KT={ktr:.2f}pp BO6={reg(bo6):.2f} rand6={reg(rand6):.2f} "
          f"adh_mean={np.mean(adh):.2f} overshoot={osr}/{len(adh)}", flush=True)
    del idx
print("SEEDDONE", flush=True)
