# KappaTune 实验代码

这里保存论文使用的研究原型和实验脚本。它不是线上服务，但已经把数据、输出、
临时文件、第三方代码和 Milvus 地址统一改成可配置项，不再依赖某台服务器的
固定目录。

## 先理解目录

- `revision-scripts/kappatune.py`：核心流程，包括 profile、召回率模型、延迟模型和预算内选型。
- `revision-scripts/path_config.py`：所有路径和服务地址的唯一配置入口。
- `revision-scripts/kappa_codebook.py`：只训练量化码本，估计未构建量化器的 κ。
- `revision-scripts/ktmulti.py`：测量 PQ、OPQ、RaBitQ、ScaNN 和 HNSW 的配置网格。
- `revision-scripts/ktkcbsel.py`：利用预测的 boundary loss 选择量化方法。
- `revision-scripts/ktxlmerge.py`：联合选择索引、码长、搜索参数和重排深度。
- `revision-scripts/ktxlfb.py`：κ 不可靠时执行实测回退。
- `revision-scripts/ktdisk.py`、`microcl.py`、`xlreprice.py`：SSD 场景实验。
- `revision-scripts/real_baseline_results/`：论文中真实 Milvus 基线的保留日志。

## 配置数据和输出目录

默认情况下，脚本在 `revision-scripts/data/` 中找数据，并把结果写入
`revision-scripts/outputs/`。实际复现实验时，建议显式设置：

```bash
export KAPPATUNE_DATA_DIR=/path/to/datasets
export KAPPATUNE_OUTPUT_DIR=/path/to/results
export KAPPATUNE_GRID_DIR=/path/to/results
```

也可以只设置 `KAPPATUNE_ROOT`。此时数据目录默认为
`$KAPPATUNE_ROOT/data`，输出目录默认为 `$KAPPATUNE_ROOT/outputs`。
完整变量见 [`environment.example`](environment.example)。

数据文件使用 ANN Benchmarks 风格的 HDF5 格式，至少需要 `train` 和
`test` 数据集；依赖 ground truth 的脚本还需要 `neighbors`。

## 最小运行示例

```bash
cd revision-scripts
OMP_NUM_THREADS=1 python kappatune.py sift-128-euclidean 0 PQ
OMP_NUM_THREADS=1 python ktmulti.py sift-128-euclidean 0 OPQ 8
python ktxlmerge.py sift-128-euclidean
```

参数中的 `0` 表示欧氏距离，`1` 表示角距离数据，并在搜索前进行 L2 归一化。

## 环境说明

核心脚本使用 NumPy、h5py 和 FAISS。贝叶斯优化实验还需要 SciPy 与
scikit-learn。ScaNN、RaBitQ 和真实 Milvus 基线通常需要独立环境，不能假设
一个 Python 环境可以运行全部脚本。建议先按照本 README 复现核心
`kappatune.py`，再逐步增加可选实验。

`vdtuner_milvus.py` 还需要：

- `KAPPATUNE_VDTUNER_DIR` 指向 VDTuner 的 `auto-configure` 目录；
- `KAPPATUNE_MILVUS_HOST` 和 `KAPPATUNE_MILVUS_PORT` 指向测试 Milvus；
- 一个允许反复创建和删除测试 collection 的隔离环境。

代码中不包含密码、Token 或真实服务器地址。不要把凭据写进
`environment.example` 或脚本；需要认证时由运行环境注入。
